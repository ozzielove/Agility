#!/usr/bin/env python3
"""
Simple Burndown Chart Test
"""

import sys
import os
sys.path.append('.')
sys.path.append('./zeus_core')

try:
    from burndown_chart import BurndownChartGenerator
    from datetime import datetime, timedelta
    import matplotlib
    matplotlib.use('Agg')
    
    print("🚀 Testing Sprint Burndown Chart Generator")
    print("=" * 50)
    
    # Test 1: Basic instantiation
    generator = BurndownChartGenerator()
    print("✅ Generator created successfully")
    
    # Test 2: Ideal line calculation
    ideal_line = generator.calculate_ideal_line(100, 40)
    assert len(ideal_line) == 41
    assert ideal_line[0] == 100
    assert abs(ideal_line[-1]) < 0.01
    print("✅ Ideal line calculation: PASS")
    
    # Test 3: Actual remaining calculation
    backlog_items = [
        {'id': 'T1', 'points': 10, 'status': 'completed', 'updated_at': datetime(2025, 7, 19, 10, 0)},
        {'id': 'T2', 'points': 15, 'status': 'open', 'updated_at': datetime(2025, 7, 19, 9, 0)}
    ]
    remaining = generator.calculate_actual_remaining(backlog_items, datetime(2025, 7, 19, 11, 0))
    assert remaining == 15  # Only open item
    print("✅ Actual remaining calculation: PASS")
    
    # Test 4: Chart data generation
    sprint_obj = {
        'id': 'TEST-001',
        'start_date': '2025-07-19T09:00:00',
        'end_date': '2025-07-19T13:00:00',  # 4 hour sprint
        'total_points': 20
    }
    
    timestamps, ideal, actual = generator.generate_chart_data(sprint_obj, backlog_items)
    assert len(timestamps) == 5  # 0,1,2,3,4 hours
    assert len(ideal) == 5
    assert len(actual) == 5
    print("✅ Chart data generation: PASS")
    
    # Test 5: Chart rendering
    chart_path = generator.render_chart(timestamps, ideal, actual, 'TEST-001')
    assert os.path.exists(chart_path)
    print(f"✅ Chart rendering: PASS (saved to {chart_path})")
    
    # Test 6: CSV data saving
    csv_path = generator.save_csv_data(timestamps, ideal, actual, 'TEST-001')
    assert os.path.exists(csv_path)
    print(f"✅ CSV data saving: PASS (saved to {csv_path})")
    
    # Test 7: End-to-end generation
    result = generator.generate_burndown_chart(sprint_obj, backlog_items)
    assert result['status'] == 'success'
    print("✅ End-to-end generation: PASS")
    
    print("\n🎉 All burndown chart tests completed successfully!")
    print("📊 System ready for hourly chart generation and S3 upload")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Test failed: {e}")
    sys.exit(1)
