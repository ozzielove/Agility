#!/usr/bin/env python3
"""
Scrum Handbook Integration Module
Implements core Scrum roles and events for Zeus Agent
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any
import json

class ProductBacklog:
    """Manages the Product Backlog with prioritization and estimation"""
    
    def __init__(self):
        self.items = []
        self.logger = logging.getLogger("Zeus.ProductBacklog")
    
    def add_item(self, title: str, description: str, priority: int = 1, 
                 story_points: int = None, acceptance_criteria: List[str] = None):
        """Add a new item to the product backlog"""
        item = {
            "id": len(self.items) + 1,
            "title": title,
            "description": description,
            "priority": priority,
            "story_points": story_points,
            "acceptance_criteria": acceptance_criteria or [],
            "status": "backlog",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        self.items.append(item)
        self.logger.info(f"Added backlog item: {title}")
        return item
    
    def prioritize(self):
        """Sort backlog items by priority"""
        self.items.sort(key=lambda x: x['priority'], reverse=True)
        self.logger.info("Product backlog prioritized")
    
    def get_top_items(self, count: int = 10):
        """Get top priority items for sprint planning"""
        self.prioritize()
        return self.items[:count]

class SprintPlanning:
    """Manages Sprint Planning activities"""
    
    def __init__(self, product_backlog: ProductBacklog):
        self.product_backlog = product_backlog
        self.current_sprint = None
        self.logger = logging.getLogger("Zeus.SprintPlanning")
    
    def plan_sprint(self, sprint_goal: str, capacity: int, duration_days: int = 14):
        """Plan a new sprint with goal and capacity"""
        sprint = {
            "id": f"sprint_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "goal": sprint_goal,
            "capacity": capacity,
            "duration_days": duration_days,
            "start_date": datetime.now().isoformat(),
            "end_date": (datetime.now() + timedelta(days=duration_days)).isoformat(),
            "backlog_items": [],
            "status": "planned"
        }
        
        # Select items for sprint based on capacity
        available_items = self.product_backlog.get_top_items()
        total_points = 0
        
        for item in available_items:
            if item['story_points'] and total_points + item['story_points'] <= capacity:
                sprint['backlog_items'].append(item)
                total_points += item['story_points']
                item['status'] = 'sprint_planned'
        
        self.current_sprint = sprint
        self.logger.info(f"Sprint planned: {sprint_goal} with {len(sprint['backlog_items'])} items")
        return sprint
    
    def start_sprint(self):
        """Start the current sprint"""
        if self.current_sprint:
            self.current_sprint['status'] = 'active'
            self.current_sprint['actual_start_date'] = datetime.now().isoformat()
            self.logger.info(f"Sprint started: {self.current_sprint['goal']}")
            return True
        return False

class DailyStandup:
    """Manages Daily Standup meetings"""
    
    def __init__(self):
        self.standups = []
        self.logger = logging.getLogger("Zeus.DailyStandup")
    
    def conduct_standup(self, team_updates: List[Dict[str, Any]]):
        """Conduct daily standup with team updates"""
        standup = {
            "date": datetime.now().isoformat(),
            "updates": team_updates,
            "impediments": [],
            "action_items": []
        }
        
        # Extract impediments and action items
        for update in team_updates:
            if 'impediments' in update:
                standup['impediments'].extend(update['impediments'])
            if 'needs_help' in update and update['needs_help']:
                standup['action_items'].append({
                    "type": "help_needed",
                    "member": update['member'],
                    "description": update.get('help_description', '')
                })
        
        self.standups.append(standup)
        self.logger.info(f"Daily standup conducted with {len(team_updates)} team members")
        return standup
    
    def get_impediments(self):
        """Get all current impediments"""
        all_impediments = []
        for standup in self.standups[-5:]:  # Last 5 standups
            all_impediments.extend(standup['impediments'])
        return list(set(all_impediments))  # Remove duplicates

class SprintReview:
    """Manages Sprint Review activities"""
    
    def __init__(self):
        self.reviews = []
        self.logger = logging.getLogger("Zeus.SprintReview")
    
    def conduct_review(self, sprint: Dict[str, Any], completed_items: List[Dict[str, Any]], 
                      stakeholder_feedback: List[str] = None):
        """Conduct sprint review"""
        review = {
            "sprint_id": sprint['id'],
            "date": datetime.now().isoformat(),
            "completed_items": completed_items,
            "stakeholder_feedback": stakeholder_feedback or [],
            "demo_notes": [],
            "next_steps": []
        }
        
        # Calculate completion metrics
        total_planned = len(sprint['backlog_items'])
        total_completed = len(completed_items)
        completion_rate = (total_completed / total_planned) * 100 if total_planned > 0 else 0
        
        review['metrics'] = {
            "planned_items": total_planned,
            "completed_items": total_completed,
            "completion_rate": completion_rate
        }
        
        self.reviews.append(review)
        self.logger.info(f"Sprint review conducted: {completion_rate:.1f}% completion rate")
        return review

class SprintRetrospective:
    """Manages Sprint Retrospective activities"""
    
    def __init__(self):
        self.retrospectives = []
        self.logger = logging.getLogger("Zeus.SprintRetrospective")
    
    def conduct_retrospective(self, sprint: Dict[str, Any], 
                            what_went_well: List[str],
                            what_could_improve: List[str],
                            action_items: List[Dict[str, Any]]):
        """Conduct sprint retrospective"""
        retrospective = {
            "sprint_id": sprint['id'],
            "date": datetime.now().isoformat(),
            "what_went_well": what_went_well,
            "what_could_improve": what_could_improve,
            "action_items": action_items,
            "team_mood": None,  # Can be set separately
            "velocity_analysis": self._analyze_velocity(sprint)
        }
        
        self.retrospectives.append(retrospective)
        self.logger.info(f"Sprint retrospective conducted with {len(action_items)} action items")
        return retrospective
    
    def _analyze_velocity(self, sprint: Dict[str, Any]):
        """Analyze team velocity for the sprint"""
        completed_points = sum(item.get('story_points', 0) 
                             for item in sprint['backlog_items'] 
                             if item.get('status') == 'completed')
        
        return {
            "planned_velocity": sprint.get('capacity', 0),
            "actual_velocity": completed_points,
            "velocity_variance": completed_points - sprint.get('capacity', 0)
        }
    
    def get_improvement_trends(self):
        """Analyze improvement trends across retrospectives"""
        if len(self.retrospectives) < 2:
            return {"message": "Need at least 2 retrospectives for trend analysis"}
        
        recent_retros = self.retrospectives[-3:]  # Last 3 retrospectives
        common_improvements = {}
        
        for retro in recent_retros:
            for improvement in retro['what_could_improve']:
                common_improvements[improvement] = common_improvements.get(improvement, 0) + 1
        
        return {
            "recurring_issues": {k: v for k, v in common_improvements.items() if v > 1},
            "total_retrospectives": len(self.retrospectives)
        }

class ScrumMaster:
    """Main Scrum Master class integrating all Scrum components"""
    
    def __init__(self):
        self.product_backlog = ProductBacklog()
        self.sprint_planning = SprintPlanning(self.product_backlog)
        self.daily_standup = DailyStandup()
        self.sprint_review = SprintReview()
        self.sprint_retrospective = SprintRetrospective()
        self.logger = logging.getLogger("Zeus.ScrumMaster")
        
        self.logger.info("Scrum Master initialized with all core components")
    
    def facilitate_scrum_process(self):
        """Main method to facilitate the complete Scrum process"""
        self.logger.info("Facilitating Scrum process...")
        
        # This would be called by the main Zeus agent
        return {
            "product_backlog": self.product_backlog,
            "sprint_planning": self.sprint_planning,
            "daily_standup": self.daily_standup,
            "sprint_review": self.sprint_review,
            "sprint_retrospective": self.sprint_retrospective
        }
    
    def get_scrum_health_metrics(self):
        """Get overall health metrics of the Scrum process"""
        return {
            "backlog_items": len(self.product_backlog.items),
            "active_sprint": self.sprint_planning.current_sprint is not None,
            "recent_standups": len(self.daily_standup.standups[-7:]),  # Last week
            "impediments_count": len(self.daily_standup.get_impediments()),
            "completed_sprints": len(self.sprint_review.reviews),
            "retrospectives_count": len(self.sprint_retrospective.retrospectives)
        }
