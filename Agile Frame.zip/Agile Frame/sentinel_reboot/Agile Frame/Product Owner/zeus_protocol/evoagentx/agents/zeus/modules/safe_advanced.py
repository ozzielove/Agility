#!/usr/bin/env python3
"""
SAFe Advanced Principles Integration Module
Implements Scaled Agile Framework concepts for Zeus Agent
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import json
from enum import Enum

class PIStatus(Enum):
    PLANNING = "planning"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class ARTRole(Enum):
    RELEASE_TRAIN_ENGINEER = "rte"
    PRODUCT_MANAGER = "pm"
    SYSTEM_ARCHITECT = "sa"
    SCRUM_MASTER = "sm"
    PRODUCT_OWNER = "po"

class PIPlanning:
    """Program Increment Planning Module for multi-sprint mission phases"""
    
    def __init__(self):
        self.program_increments = []
        self.current_pi = None
        self.logger = logging.getLogger("Zeus.PIPlanning")
    
    def create_program_increment(self, pi_name: str, duration_weeks: int = 10, 
                               objectives: List[str] = None, teams: List[str] = None):
        """Create a new Program Increment"""
        pi = {
            "id": f"PI_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": pi_name,
            "duration_weeks": duration_weeks,
            "start_date": datetime.now().isoformat(),
            "end_date": (datetime.now() + timedelta(weeks=duration_weeks)).isoformat(),
            "objectives": objectives or [],
            "teams": teams or [],
            "status": PIStatus.PLANNING.value,
            "sprints": [],
            "features": [],
            "risks": [],
            "dependencies": [],
            "confidence_vote": None,
            "created_at": datetime.now().isoformat()
        }
        
        # Generate sprint structure for the PI
        sprints_count = duration_weeks // 2  # Assuming 2-week sprints
        for i in range(sprints_count):
            sprint_start = datetime.now() + timedelta(weeks=i*2)
            sprint_end = sprint_start + timedelta(weeks=2)
            
            sprint = {
                "sprint_number": i + 1,
                "start_date": sprint_start.isoformat(),
                "end_date": sprint_end.isoformat(),
                "goals": [],
                "features": [],
                "status": "planned"
            }
            pi["sprints"].append(sprint)
        
        self.program_increments.append(pi)
        self.current_pi = pi
        self.logger.info(f"Created Program Increment: {pi_name} with {sprints_count} sprints")
        return pi
    
    def add_pi_objective(self, objective: str, business_value: int, 
                        assigned_teams: List[str] = None):
        """Add objective to current PI"""
        if not self.current_pi:
            raise ValueError("No active Program Increment")
        
        pi_objective = {
            "id": len(self.current_pi["objectives"]) + 1,
            "description": objective,
            "business_value": business_value,
            "assigned_teams": assigned_teams or [],
            "status": "planned",
            "progress": 0,
            "created_at": datetime.now().isoformat()
        }
        
        self.current_pi["objectives"].append(pi_objective)
        self.logger.info(f"Added PI objective: {objective}")
        return pi_objective
    
    def conduct_confidence_vote(self, team_votes: Dict[str, int]):
        """Conduct PI confidence vote (1-5 scale)"""
        if not self.current_pi:
            raise ValueError("No active Program Increment")
        
        total_votes = sum(team_votes.values())
        average_confidence = total_votes / len(team_votes) if team_votes else 0
        
        confidence_result = {
            "date": datetime.now().isoformat(),
            "team_votes": team_votes,
            "average_confidence": average_confidence,
            "status": "high" if average_confidence >= 3.5 else "medium" if average_confidence >= 2.5 else "low"
        }
        
        self.current_pi["confidence_vote"] = confidence_result
        self.logger.info(f"PI confidence vote completed: {average_confidence:.1f}/5.0")
        return confidence_result
    
    def start_pi_execution(self):
        """Start executing the current PI"""
        if self.current_pi and self.current_pi["status"] == PIStatus.PLANNING.value:
            self.current_pi["status"] = PIStatus.ACTIVE.value
            self.current_pi["actual_start_date"] = datetime.now().isoformat()
            self.logger.info(f"Started PI execution: {self.current_pi['name']}")
            return True
        return False

class ARTSync:
    """Agile Release Train Synchronization Protocol"""
    
    def __init__(self):
        self.art_members = {}
        self.scrum_of_scrums = []
        self.po_sync_meetings = []
        self.logger = logging.getLogger("Zeus.ARTSync")
    
    def register_art_member(self, member_id: str, role: ARTRole, team: str, 
                          contact_info: Dict[str, str] = None):
        """Register a member of the Agile Release Train"""
        member = {
            "id": member_id,
            "role": role.value,
            "team": team,
            "contact_info": contact_info or {},
            "registered_at": datetime.now().isoformat(),
            "active": True
        }
        
        self.art_members[member_id] = member
        self.logger.info(f"Registered ART member: {member_id} as {role.value} in {team}")
        return member
    
    def conduct_scrum_of_scrums(self, team_updates: List[Dict[str, Any]]):
        """Conduct Scrum of Scrums meeting"""
        scrum_of_scrums = {
            "date": datetime.now().isoformat(),
            "facilitator": "Zeus",
            "team_updates": team_updates,
            "cross_team_dependencies": [],
            "impediments": [],
            "action_items": [],
            "next_meeting": (datetime.now() + timedelta(days=1)).isoformat()
        }
        
        # Extract cross-team information
        for update in team_updates:
            if 'dependencies' in update:
                scrum_of_scrums['cross_team_dependencies'].extend(update['dependencies'])
            if 'impediments' in update:
                scrum_of_scrums['impediments'].extend(update['impediments'])
            if 'help_needed_from' in update:
                action_item = {
                    "type": "cross_team_help",
                    "requesting_team": update['team'],
                    "target_team": update['help_needed_from'],
                    "description": update.get('help_description', ''),
                    "priority": update.get('priority', 'medium')
                }
                scrum_of_scrums['action_items'].append(action_item)
        
        self.scrum_of_scrums.append(scrum_of_scrums)
        self.logger.info(f"Scrum of Scrums conducted with {len(team_updates)} teams")
        return scrum_of_scrums
    
    def conduct_po_sync(self, product_owners: List[str], 
                       backlog_alignments: List[Dict[str, Any]]):
        """Conduct Product Owner Sync meeting"""
        po_sync = {
            "date": datetime.now().isoformat(),
            "attendees": product_owners,
            "backlog_alignments": backlog_alignments,
            "feature_priorities": [],
            "market_feedback": [],
            "roadmap_updates": [],
            "decisions": []
        }
        
        # Process backlog alignments
        for alignment in backlog_alignments:
            if alignment.get('priority_change'):
                po_sync['feature_priorities'].append({
                    "feature": alignment['feature'],
                    "old_priority": alignment.get('old_priority'),
                    "new_priority": alignment['new_priority'],
                    "reason": alignment.get('reason', '')
                })
        
        self.po_sync_meetings.append(po_sync)
        self.logger.info(f"PO Sync conducted with {len(product_owners)} Product Owners")
        return po_sync
    
    def get_art_health_metrics(self):
        """Get ART health and synchronization metrics"""
        active_members = sum(1 for member in self.art_members.values() if member['active'])
        recent_scrums = len([s for s in self.scrum_of_scrums 
                           if datetime.fromisoformat(s['date']) > datetime.now() - timedelta(days=7)])
        
        return {
            "total_art_members": len(self.art_members),
            "active_members": active_members,
            "recent_scrum_of_scrums": recent_scrums,
            "recent_po_syncs": len(self.po_sync_meetings[-7:]),
            "cross_team_dependencies": len(set(dep for sos in self.scrum_of_scrums[-5:] 
                                              for dep in sos.get('cross_team_dependencies', []))),
            "active_impediments": len(set(imp for sos in self.scrum_of_scrums[-3:] 
                                        for imp in sos.get('impediments', [])))
        }

class InspectAndAdapt:
    """Inspect & Adapt Logic for end-of-phase analysis and problem-solving"""
    
    def __init__(self):
        self.ia_sessions = []
        self.improvement_backlog = []
        self.logger = logging.getLogger("Zeus.InspectAndAdapt")
    
    def conduct_ia_session(self, pi_data: Dict[str, Any], 
                          quantitative_metrics: Dict[str, float],
                          qualitative_feedback: List[str]):
        """Conduct Inspect & Adapt session"""
        ia_session = {
            "date": datetime.now().isoformat(),
            "pi_id": pi_data.get('id'),
            "pi_name": pi_data.get('name'),
            "quantitative_metrics": quantitative_metrics,
            "qualitative_feedback": qualitative_feedback,
            "problem_solving_workshop": None,
            "improvement_items": [],
            "action_plans": []
        }
        
        # Analyze metrics for problems
        problems_identified = self._analyze_metrics_for_problems(quantitative_metrics)
        ia_session['problems_identified'] = problems_identified
        
        # If problems found, trigger problem-solving workshop
        if problems_identified:
            workshop_result = self._conduct_problem_solving_workshop(problems_identified)
            ia_session['problem_solving_workshop'] = workshop_result
        
        self.ia_sessions.append(ia_session)
        self.logger.info(f"I&A session conducted for PI: {pi_data.get('name')}")
        return ia_session
    
    def _analyze_metrics_for_problems(self, metrics: Dict[str, float]):
        """Analyze quantitative metrics to identify problems"""
        problems = []
        
        # Define thresholds for problem identification
        thresholds = {
            "velocity_variance": 20,  # % variance from planned
            "defect_rate": 5,  # % defects
            "cycle_time": 10,  # days
            "team_satisfaction": 3.0,  # out of 5
            "customer_satisfaction": 3.5  # out of 5
        }
        
        for metric, value in metrics.items():
            if metric in thresholds:
                if metric in ["velocity_variance", "defect_rate", "cycle_time"]:
                    if value > thresholds[metric]:
                        problems.append({
                            "metric": metric,
                            "actual_value": value,
                            "threshold": thresholds[metric],
                            "severity": "high" if value > thresholds[metric] * 1.5 else "medium"
                        })
                elif metric in ["team_satisfaction", "customer_satisfaction"]:
                    if value < thresholds[metric]:
                        problems.append({
                            "metric": metric,
                            "actual_value": value,
                            "threshold": thresholds[metric],
                            "severity": "high" if value < thresholds[metric] * 0.7 else "medium"
                        })
        
        return problems
    
    def _conduct_problem_solving_workshop(self, problems: List[Dict[str, Any]]):
        """Conduct problem-solving workshop using structured approach"""
        workshop = {
            "date": datetime.now().isoformat(),
            "problems_addressed": problems,
            "root_cause_analysis": [],
            "solution_options": [],
            "selected_solutions": [],
            "implementation_plan": []
        }
        
        # For each problem, apply 5 Whys technique (simplified)
        for problem in problems:
            root_cause = {
                "problem": problem['metric'],
                "why_analysis": [
                    f"Why is {problem['metric']} at {problem['actual_value']}?",
                    "Why did the underlying process fail?",
                    "Why wasn't this detected earlier?",
                    "Why don't we have better controls?",
                    "Why isn't our system more resilient?"
                ],
                "root_cause_hypothesis": f"Systemic issue in {problem['metric']} management"
            }
            workshop['root_cause_analysis'].append(root_cause)
            
            # Generate solution options
            solutions = [
                f"Implement better monitoring for {problem['metric']}",
                f"Establish early warning system for {problem['metric']}",
                f"Create process improvement team for {problem['metric']}",
                f"Provide additional training on {problem['metric']} management"
            ]
            workshop['solution_options'].extend(solutions)
        
        return workshop
    
    def create_improvement_item(self, title: str, description: str, 
                              priority: str = "medium", estimated_effort: str = "medium"):
        """Create improvement backlog item"""
        improvement_item = {
            "id": len(self.improvement_backlog) + 1,
            "title": title,
            "description": description,
            "priority": priority,
            "estimated_effort": estimated_effort,
            "status": "backlog",
            "created_at": datetime.now().isoformat(),
            "assigned_to": None,
            "target_completion": None
        }
        
        self.improvement_backlog.append(improvement_item)
        self.logger.info(f"Created improvement item: {title}")
        return improvement_item
    
    def get_improvement_metrics(self):
        """Get metrics on improvement initiatives"""
        total_items = len(self.improvement_backlog)
        completed_items = len([item for item in self.improvement_backlog 
                             if item['status'] == 'completed'])
        
        return {
            "total_improvement_items": total_items,
            "completed_improvements": completed_items,
            "completion_rate": (completed_items / total_items * 100) if total_items > 0 else 0,
            "ia_sessions_conducted": len(self.ia_sessions),
            "problems_identified": sum(len(session.get('problems_identified', [])) 
                                     for session in self.ia_sessions),
            "workshops_conducted": len([session for session in self.ia_sessions 
                                      if session.get('problem_solving_workshop')])
        }

class SAFeAdvancedScrumMaster:
    """Advanced Scrum Master with SAFe integration"""
    
    def __init__(self):
        self.pi_planning = PIPlanning()
        self.art_sync = ARTSync()
        self.inspect_adapt = InspectAndAdapt()
        self.logger = logging.getLogger("Zeus.SAFeAdvanced")
        
        # Register Zeus as RTE (Release Train Engineer)
        self.art_sync.register_art_member(
            "zeus_rte", 
            ARTRole.RELEASE_TRAIN_ENGINEER, 
            "Zeus_Command",
            {"role": "AI Scrum Master", "capabilities": "Full SAFe facilitation"}
        )
        
        self.logger.info("SAFe Advanced Scrum Master initialized")
    
    def facilitate_safe_process(self):
        """Main method to facilitate SAFe processes"""
        self.logger.info("Facilitating SAFe advanced processes...")
        
        return {
            "pi_planning": self.pi_planning,
            "art_sync": self.art_sync,
            "inspect_adapt": self.inspect_adapt
        }
    
    def get_safe_health_dashboard(self):
        """Get comprehensive SAFe health metrics"""
        pi_metrics = {
            "active_pi": self.pi_planning.current_pi is not None,
            "total_pis": len(self.pi_planning.program_increments)
        }
        
        art_metrics = self.art_sync.get_art_health_metrics()
        improvement_metrics = self.inspect_adapt.get_improvement_metrics()
        
        return {
            "pi_planning": pi_metrics,
            "art_synchronization": art_metrics,
            "continuous_improvement": improvement_metrics,
            "overall_health": self._calculate_overall_health(pi_metrics, art_metrics, improvement_metrics)
        }
    
    def _calculate_overall_health(self, pi_metrics, art_metrics, improvement_metrics):
        """Calculate overall SAFe implementation health score"""
        health_score = 0
        max_score = 100
        
        # PI Planning health (30 points)
        if pi_metrics['active_pi']:
            health_score += 20
        if pi_metrics['total_pis'] > 0:
            health_score += 10
        
        # ART Sync health (40 points)
        if art_metrics['active_members'] > 0:
            health_score += 15
        if art_metrics['recent_scrum_of_scrums'] > 0:
            health_score += 15
        if art_metrics['active_impediments'] < 5:  # Low impediment count is good
            health_score += 10
        
        # Continuous Improvement health (30 points)
        if improvement_metrics['ia_sessions_conducted'] > 0:
            health_score += 15
        if improvement_metrics['completion_rate'] > 50:
            health_score += 15
        
        return {
            "score": health_score,
            "max_score": max_score,
            "percentage": (health_score / max_score) * 100,
            "status": "excellent" if health_score > 80 else "good" if health_score > 60 else "needs_improvement"
        }
