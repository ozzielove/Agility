#!/usr/bin/env python3
"""
Agent Velvet - Strategic Auditor Service
Specialized agent for strategic and brand alignment validation
"""

import os
import json
import asyncio
import aiohttp
from flask import Flask, jsonify, request
from datetime import datetime
import logging
import re

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('AgentVelvet')

app = Flask(__name__)

class StrategicAuditor:
    def __init__(self):
        self.agent_role = os.getenv('AGENT_ROLE', 'Velvet_Strategic_Auditor')
        self.agent_id = os.getenv('AGENT_ID', 'velvet-001')
        self.governance_mode = os.getenv('GOVERNANCE_MODE', 'enabled')
        self.brand_alignment = os.getenv('BRAND_ALIGNMENT', 'strict')
        self.ethical_validation = os.getenv('ETHICAL_VALIDATION', 'true').lower() == 'true'
        self.qdrant_host = os.getenv('QDRANT_HOST', 'qdrant')
        self.qdrant_port = os.getenv('QDRANT_PORT', '6333')
        
        # Load Strategic Governance Module
        self.governance_config = self.load_governance_config()
        
        logger.info(f"Agent Velvet initialized: {self.agent_id}")
        logger.info(f"Governance Mode: {self.governance_mode}")
        logger.info(f"Brand Alignment: {self.brand_alignment}")
        logger.info(f"Ethical Validation: {self.ethical_validation}")
    
    def load_governance_config(self):
        """Load Strategic Governance Module configuration"""
        try:
            with open('/app/strategic-governance-module.json', 'r') as f:
                config = json.load(f)
                logger.info("Strategic Governance Module loaded successfully")
                return config['strategic_governance']
        except Exception as e:
            logger.warning(f"Could not load governance config: {e}")
            return self.get_default_governance_config()
    
    def get_default_governance_config(self):
        """Default governance configuration if file not available"""
        return {
            "company_info": {
                "name": "Vercept",
                "mission": "Empowering intelligent automation through advanced AI agents",
                "values": ["Innovation", "Reliability", "Transparency", "Ethical AI"]
            },
            "brand_voice": {
                "tone": "Professional yet approachable",
                "personality": "Intelligent, reliable, innovative"
            },
            "ethical_guidelines": {
                "prohibited_actions": [
                    "Misleading practices",
                    "Privacy violations",
                    "Harmful activities"
                ]
            }
        }
    
    async def validate_okr_alignment(self, strategy):
        """Validate strategy alignment with OKRs"""
        results = {
            'timestamp': datetime.utcnow().isoformat(),
            'strategy': strategy,
            'validation_type': 'okr_alignment',
            'alignment_score': 0.0,
            'findings': []
        }
        
        okrs = self.governance_config.get('okrs', {}).get('q4_2025', {})
        alignment_score = 0.0
        total_objectives = len(okrs)
        
        for obj_key, objective in okrs.items():
            obj_alignment = self.check_objective_alignment(strategy, objective)
            alignment_score += obj_alignment['score']
            
            if obj_alignment['score'] > 0.7:
                results['findings'].append({
                    'type': 'strong_alignment',
                    'objective': objective['title'],
                    'score': obj_alignment['score'],
                    'description': f"Strategy strongly aligns with {objective['title']}"
                })
            elif obj_alignment['score'] < 0.3:
                results['findings'].append({
                    'type': 'weak_alignment',
                    'objective': objective['title'],
                    'score': obj_alignment['score'],
                    'description': f"Strategy may conflict with {objective['title']}"
                })
        
        results['alignment_score'] = alignment_score / total_objectives if total_objectives > 0 else 0.0
        results['status'] = 'validated'
        
        logger.info(f"OKR alignment validation completed: {results['alignment_score']:.2f}")
        return results
    
    def check_objective_alignment(self, strategy, objective):
        """Check alignment between strategy and specific objective"""
        strategy_lower = strategy.lower()
        title_lower = objective['title'].lower()
        
        # Simple keyword matching for demonstration
        alignment_keywords = {
            'reliability': ['reliable', 'uptime', 'stable', 'consistent'],
            'security': ['secure', 'security', 'protection', 'safe'],
            'user experience': ['user', 'experience', 'interface', 'usability'],
            'performance': ['fast', 'performance', 'speed', 'efficient']
        }
        
        score = 0.0
        for category, keywords in alignment_keywords.items():
            if any(keyword in title_lower for keyword in keywords):
                if any(keyword in strategy_lower for keyword in keywords):
                    score += 0.3
        
        # Boost score if strategy directly mentions objective themes
        if any(word in strategy_lower for word in title_lower.split()):
            score += 0.4
        
        return {'score': min(score, 1.0)}
    
    async def validate_brand_voice(self, content):
        """Validate content against brand voice guidelines"""
        results = {
            'timestamp': datetime.utcnow().isoformat(),
            'content_hash': hash(content) % 10000,
            'validation_type': 'brand_voice',
            'compliance_score': 0.0,
            'issues': []
        }
        
        brand_voice = self.governance_config.get('brand_voice', {})
        tone = brand_voice.get('tone', 'Professional yet approachable')
        
        # Check for brand voice compliance
        compliance_score = 0.8  # Base score
        
        # Check for overly technical language
        technical_terms = ['algorithm', 'implementation', 'configuration', 'deployment']
        tech_count = sum(1 for term in technical_terms if term in content.lower())
        if tech_count > 3:
            compliance_score -= 0.2
            results['issues'].append({
                'type': 'technical_density',
                'severity': 'medium',
                'description': 'Content may be too technical for general audience'
            })
        
        # Check for appropriate tone
        if any(word in content.lower() for word in ['obviously', 'clearly', 'simply']):
            compliance_score -= 0.1
            results['issues'].append({
                'type': 'tone_issue',
                'severity': 'low',
                'description': 'Avoid condescending language'
            })
        
        # Check for positive, innovative language
        positive_words = ['innovative', 'advanced', 'reliable', 'efficient', 'intelligent']
        if any(word in content.lower() for word in positive_words):
            compliance_score += 0.1
        
        results['compliance_score'] = max(0.0, min(1.0, compliance_score))
        results['status'] = 'analyzed'
        
        logger.info(f"Brand voice validation completed: {results['compliance_score']:.2f}")
        return results
    
    async def validate_ethical_guidelines(self, strategy):
        """Validate strategy against ethical guidelines"""
        results = {
            'timestamp': datetime.utcnow().isoformat(),
            'strategy': strategy,
            'validation_type': 'ethical_compliance',
            'compliance_status': 'compliant',
            'violations': []
        }
        
        ethical_guidelines = self.governance_config.get('ethical_guidelines', {})
        prohibited_actions = ethical_guidelines.get('prohibited_actions', [])
        
        strategy_lower = strategy.lower()
        
        # Check for prohibited actions
        violation_keywords = {
            'misleading': ['mislead', 'deceive', 'false', 'fake'],
            'privacy': ['collect personal', 'track users', 'harvest data'],
            'harmful': ['attack', 'exploit', 'damage', 'harm'],
            'bias': ['discriminate', 'exclude', 'bias against']
        }
        
        for violation_type, keywords in violation_keywords.items():
            for keyword in keywords:
                if keyword in strategy_lower:
                    results['violations'].append({
                        'type': violation_type,
                        'severity': 'high',
                        'keyword': keyword,
                        'description': f"Strategy may involve {violation_type} practices"
                    })
                    results['compliance_status'] = 'non_compliant'
        
        # Check for positive ethical indicators
        ethical_indicators = ['transparent', 'fair', 'responsible', 'ethical', 'privacy-preserving']
        if any(indicator in strategy_lower for indicator in ethical_indicators):
            results['ethical_score'] = 0.9
        else:
            results['ethical_score'] = 0.7 if results['compliance_status'] == 'compliant' else 0.3
        
        results['status'] = 'validated'
        
        logger.info(f"Ethical validation completed: {results['compliance_status']}")
        return results
    
    async def comprehensive_strategic_audit(self, strategy):
        """Perform comprehensive strategic audit"""
        audit_results = {
            'timestamp': datetime.utcnow().isoformat(),
            'strategy': strategy,
            'audit_type': 'comprehensive_strategic',
            'overall_score': 0.0,
            'recommendations': []
        }
        
        # Run all validations
        okr_results = await self.validate_okr_alignment(strategy)
        brand_results = await self.validate_brand_voice(strategy)
        ethical_results = await self.validate_ethical_guidelines(strategy)
        
        # Calculate overall score
        overall_score = (
            okr_results['alignment_score'] * 0.4 +
            brand_results['compliance_score'] * 0.3 +
            ethical_results['ethical_score'] * 0.3
        )
        
        audit_results['overall_score'] = overall_score
        audit_results['okr_alignment'] = okr_results
        audit_results['brand_compliance'] = brand_results
        audit_results['ethical_compliance'] = ethical_results
        
        # Generate recommendations
        if overall_score < 0.6:
            audit_results['recommendations'].append("Strategy requires significant revision to meet standards")
        elif overall_score < 0.8:
            audit_results['recommendations'].append("Strategy needs minor adjustments for optimal alignment")
        else:
            audit_results['recommendations'].append("Strategy demonstrates strong strategic alignment")
        
        audit_results['status'] = 'completed'
        
        logger.info(f"Comprehensive audit completed: {overall_score:.2f}")
        return audit_results

# Initialize the auditor
auditor = StrategicAuditor()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'agent_role': auditor.agent_role,
        'agent_id': auditor.agent_id,
        'governance_mode': auditor.governance_mode,
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/audit/okr', methods=['POST'])
async def okr_audit():
    data = request.get_json()
    strategy = data.get('strategy', '')
    
    results = await auditor.validate_okr_alignment(strategy)
    return jsonify(results)

@app.route('/audit/brand', methods=['POST'])
async def brand_audit():
    data = request.get_json()
    content = data.get('content', '')
    
    results = await auditor.validate_brand_voice(content)
    return jsonify(results)

@app.route('/audit/ethics', methods=['POST'])
async def ethics_audit():
    data = request.get_json()
    strategy = data.get('strategy', '')
    
    results = await auditor.validate_ethical_guidelines(strategy)
    return jsonify(results)

@app.route('/audit/comprehensive', methods=['POST'])
async def comprehensive_audit():
    data = request.get_json()
    strategy = data.get('strategy', '')
    
    results = await auditor.comprehensive_strategic_audit(strategy)
    return jsonify(results)

@app.route('/governance', methods=['GET'])
def get_governance_config():
    return jsonify({
        'governance_config': auditor.governance_config,
        'access_level': 'read_only',
        'last_updated': datetime.utcnow().isoformat()
    })

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify({
        'agent_role': auditor.agent_role,
        'agent_id': auditor.agent_id,
        'governance_mode': auditor.governance_mode,
        'brand_alignment': auditor.brand_alignment,
        'ethical_validation': auditor.ethical_validation,
        'qdrant_connection': f"{auditor.qdrant_host}:{auditor.qdrant_port}",
        'governance_config_loaded': bool(auditor.governance_config),
        'uptime': datetime.utcnow().isoformat(),
        'status': 'operational'
    })

if __name__ == '__main__':
    logger.info("Starting Agent Velvet Strategic Auditor Service")
    app.run(host='0.0.0.0', port=8090, debug=True)
