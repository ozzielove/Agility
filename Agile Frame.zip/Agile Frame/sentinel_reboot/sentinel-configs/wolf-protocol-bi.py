#!/usr/bin/env python3
"""
Wolf Protocol - Business Intelligence Agent
Proactive BI agent for autonomous mission initiation and KPI analysis
"""

import os
import json
import asyncio
import psycopg2
import pandas as pd
from flask import Flask, jsonify, request
from datetime import datetime, timedelta
import logging
import numpy as np
from typing import Dict, List, Any

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('WolfProtocol')

app = Flask(__name__)

class WolfProtocolBI:
    def __init__(self):
        self.agent_role = os.getenv('AGENT_ROLE', 'Wolf_BI_Protocol')
        self.agent_id = os.getenv('AGENT_ID', 'wolf-001')
        self.analysis_mode = os.getenv('ANALYSIS_MODE', 'continuous')
        self.alert_threshold = float(os.getenv('ALERT_THRESHOLD', '0.15'))  # 15% negative delta
        
        # Database configuration
        self.db_host = os.getenv('DB_HOST', 'postgres-analytics')
        self.db_port = os.getenv('DB_PORT', '5432')
        self.db_name = os.getenv('DB_NAME', 'analytics_warehouse')
        self.db_user = os.getenv('DB_USER', 'wolf_protocol')
        self.db_password = os.getenv('DB_PASSWORD', 'secure_analytics_2025')
        
        # Primary objective
        self.primary_objective = "Identify and quantify the largest negative delta against primary business KPIs"
        
        # KPI definitions
        self.primary_kpis = {
            'revenue': {
                'target': 1000000,  # $1M monthly target
                'weight': 0.3,
                'unit': 'USD',
                'description': 'Monthly recurring revenue'
            },
            'user_acquisition': {
                'target': 5000,  # 5K new users monthly
                'weight': 0.25,
                'unit': 'users',
                'description': 'New user signups per month'
            },
            'system_uptime': {
                'target': 99.9,  # 99.9% uptime
                'weight': 0.2,
                'unit': 'percentage',
                'description': 'System availability percentage'
            },
            'customer_satisfaction': {
                'target': 4.5,  # 4.5/5 rating
                'weight': 0.15,
                'unit': 'rating',
                'description': 'Average customer satisfaction score'
            },
            'response_time': {
                'target': 2.0,  # 2 seconds max
                'weight': 0.1,
                'unit': 'seconds',
                'description': 'Average API response time',
                'inverse': True  # Lower is better
            }
        }
        
        self.mission_queue = []
        self.analysis_history = []
        
        logger.info(f"Wolf Protocol initialized: {self.agent_id}")
        logger.info(f"Primary objective: {self.primary_objective}")
        logger.info(f"Monitoring {len(self.primary_kpis)} primary KPIs")
        
        # Initialize database
        self.init_database()
    
    def get_db_connection(self):
        """Get database connection"""
        try:
            conn = psycopg2.connect(
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
                user=self.db_user,
                password=self.db_password
            )
            return conn
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return None
    
    def init_database(self):
        """Initialize database with sample KPI data"""
        conn = self.get_db_connection()
        if not conn:
            logger.warning("Could not initialize database - using mock data")
            return
        
        try:
            cursor = conn.cursor()
            
            # Create KPI metrics table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS kpi_metrics (
                    id SERIAL PRIMARY KEY,
                    kpi_name VARCHAR(100) NOT NULL,
                    value DECIMAL(15,2) NOT NULL,
                    target_value DECIMAL(15,2) NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    period VARCHAR(50) DEFAULT 'monthly'
                )
            """)
            
            # Create business opportunities table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS business_opportunities (
                    id SERIAL PRIMARY KEY,
                    opportunity_type VARCHAR(100) NOT NULL,
                    description TEXT,
                    impact_score DECIMAL(5,2),
                    urgency_level VARCHAR(20),
                    identified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status VARCHAR(50) DEFAULT 'identified'
                )
            """)
            
            # Insert sample KPI data for analysis
            sample_data = [
                ('revenue', 850000, 1000000),  # 15% below target
                ('user_acquisition', 3200, 5000),  # 36% below target
                ('system_uptime', 99.2, 99.9),  # 0.7% below target
                ('customer_satisfaction', 4.2, 4.5),  # 6.7% below target
                ('response_time', 3.2, 2.0)  # 60% above target (worse)
            ]
            
            for kpi_name, value, target in sample_data:
                cursor.execute("""
                    INSERT INTO kpi_metrics (kpi_name, value, target_value) 
                    VALUES (%s, %s, %s)
                    ON CONFLICT DO NOTHING
                """, (kpi_name, value, target))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            logger.info("Database initialized with sample KPI data")
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            if conn:
                conn.close()
    
    async def analyze_kpi_performance(self):
        """Analyze KPI performance and identify negative deltas"""
        analysis_results = {
            'timestamp': datetime.utcnow().isoformat(),
            'analysis_type': 'kpi_performance',
            'kpi_analysis': {},
            'critical_issues': [],
            'opportunities': [],
            'overall_health_score': 0.0
        }
        
        conn = self.get_db_connection()
        if not conn:
            # Use mock data if database unavailable
            return await self.analyze_mock_kpi_data()
        
        try:
            cursor = conn.cursor()
            
            total_weighted_score = 0.0
            total_weight = 0.0
            
            for kpi_name, kpi_config in self.primary_kpis.items():
                # Get latest KPI value
                cursor.execute("""
                    SELECT value, target_value, timestamp 
                    FROM kpi_metrics 
                    WHERE kpi_name = %s 
                    ORDER BY timestamp DESC 
                    LIMIT 1
                """, (kpi_name,))
                
                result = cursor.fetchone()
                if result:
                    current_value, target_value, timestamp = result
                    
                    # Calculate delta
                    if kpi_config.get('inverse', False):
                        # For metrics where lower is better (e.g., response time)
                        delta_percentage = (current_value - target_value) / target_value
                        performance_score = max(0, 1 - delta_percentage)
                    else:
                        # For metrics where higher is better
                        delta_percentage = (current_value - target_value) / target_value
                        performance_score = max(0, 1 + delta_percentage)
                    
                    weighted_score = performance_score * kpi_config['weight']
                    total_weighted_score += weighted_score
                    total_weight += kpi_config['weight']
                    
                    kpi_analysis = {
                        'current_value': float(current_value),
                        'target_value': float(target_value),
                        'delta_percentage': round(delta_percentage * 100, 2),
                        'performance_score': round(performance_score, 3),
                        'weight': kpi_config['weight'],
                        'weighted_score': round(weighted_score, 3),
                        'unit': kpi_config['unit'],
                        'description': kpi_config['description'],
                        'last_updated': timestamp.isoformat()
                    }
                    
                    analysis_results['kpi_analysis'][kpi_name] = kpi_analysis
                    
                    # Identify critical issues
                    if abs(delta_percentage) > self.alert_threshold:
                        severity = 'critical' if abs(delta_percentage) > 0.3 else 'high'
                        
                        analysis_results['critical_issues'].append({
                            'kpi': kpi_name,
                            'severity': severity,
                            'delta_percentage': round(delta_percentage * 100, 2),
                            'impact': f"{kpi_config['description']} is {abs(delta_percentage)*100:.1f}% {'above' if delta_percentage > 0 and not kpi_config.get('inverse') else 'below'} target",
                            'recommended_action': self.get_recommended_action(kpi_name, delta_percentage)
                        })
            
            # Calculate overall health score
            analysis_results['overall_health_score'] = round(total_weighted_score / total_weight if total_weight > 0 else 0.0, 3)
            
            cursor.close()
            conn.close()
            
        except Exception as e:
            logger.error(f"KPI analysis failed: {e}")
            if conn:
                conn.close()
            return await self.analyze_mock_kpi_data()
        
        # Generate business opportunities
        analysis_results['opportunities'] = await self.identify_business_opportunities(analysis_results)
        
        logger.info(f"KPI analysis completed. Health score: {analysis_results['overall_health_score']}")
        return analysis_results
    
    async def analyze_mock_kpi_data(self):
        """Analyze mock KPI data when database is unavailable"""
        mock_data = {
            'revenue': {'current': 850000, 'target': 1000000},
            'user_acquisition': {'current': 3200, 'target': 5000},
            'system_uptime': {'current': 99.2, 'target': 99.9},
            'customer_satisfaction': {'current': 4.2, 'target': 4.5},
            'response_time': {'current': 3.2, 'target': 2.0}
        }
        
        analysis_results = {
            'timestamp': datetime.utcnow().isoformat(),
            'analysis_type': 'kpi_performance_mock',
            'kpi_analysis': {},
            'critical_issues': [],
            'opportunities': [],
            'overall_health_score': 0.0
        }
        
        total_weighted_score = 0.0
        total_weight = 0.0
        
        for kpi_name, kpi_config in self.primary_kpis.items():
            if kpi_name in mock_data:
                current_value = mock_data[kpi_name]['current']
                target_value = mock_data[kpi_name]['target']
                
                # Calculate delta
                if kpi_config.get('inverse', False):
                    delta_percentage = (current_value - target_value) / target_value
                    performance_score = max(0, 1 - delta_percentage)
                else:
                    delta_percentage = (current_value - target_value) / target_value
                    performance_score = max(0, 1 + delta_percentage)
                
                weighted_score = performance_score * kpi_config['weight']
                total_weighted_score += weighted_score
                total_weight += kpi_config['weight']
                
                analysis_results['kpi_analysis'][kpi_name] = {
                    'current_value': current_value,
                    'target_value': target_value,
                    'delta_percentage': round(delta_percentage * 100, 2),
                    'performance_score': round(performance_score, 3),
                    'weight': kpi_config['weight'],
                    'weighted_score': round(weighted_score, 3),
                    'unit': kpi_config['unit'],
                    'description': kpi_config['description']
                }
                
                # Identify critical issues
                if abs(delta_percentage) > self.alert_threshold:
                    severity = 'critical' if abs(delta_percentage) > 0.3 else 'high'
                    
                    analysis_results['critical_issues'].append({
                        'kpi': kpi_name,
                        'severity': severity,
                        'delta_percentage': round(delta_percentage * 100, 2),
                        'impact': f"{kpi_config['description']} is {abs(delta_percentage)*100:.1f}% {'above' if delta_percentage > 0 and not kpi_config.get('inverse') else 'below'} target",
                        'recommended_action': self.get_recommended_action(kpi_name, delta_percentage)
                    })
        
        analysis_results['overall_health_score'] = round(total_weighted_score / total_weight if total_weight > 0 else 0.0, 3)
        analysis_results['opportunities'] = await self.identify_business_opportunities(analysis_results)
        
        return analysis_results
    
    def get_recommended_action(self, kpi_name: str, delta_percentage: float) -> str:
        """Get recommended action for KPI improvement"""
        actions = {
            'revenue': 'Implement revenue optimization strategies, review pricing model, enhance upselling',
            'user_acquisition': 'Increase marketing spend, optimize conversion funnel, improve onboarding',
            'system_uptime': 'Investigate infrastructure issues, implement redundancy, enhance monitoring',
            'customer_satisfaction': 'Analyze customer feedback, improve support processes, enhance product features',
            'response_time': 'Optimize database queries, implement caching, scale infrastructure'
        }
        
        return actions.get(kpi_name, 'Investigate root cause and implement corrective measures')
    
    async def identify_business_opportunities(self, analysis_results: Dict) -> List[Dict]:
        """Identify business opportunities based on KPI analysis"""
        opportunities = []
        
        # Find the largest negative delta
        largest_negative_delta = 0
        worst_kpi = None
        
        for kpi_name, kpi_data in analysis_results['kpi_analysis'].items():
            delta = kpi_data['delta_percentage']
            if delta < largest_negative_delta:
                largest_negative_delta = delta
                worst_kpi = kpi_name
        
        if worst_kpi:
            opportunities.append({
                'type': 'critical_improvement',
                'kpi': worst_kpi,
                'impact_score': abs(largest_negative_delta),
                'description': f"Address {worst_kpi} performance gap of {abs(largest_negative_delta):.1f}%",
                'urgency': 'high',
                'estimated_impact': f"Potential {abs(largest_negative_delta) * 0.5:.1f}% business improvement"
            })
        
        # Identify cross-KPI opportunities
        if len(analysis_results['critical_issues']) > 2:
            opportunities.append({
                'type': 'systematic_improvement',
                'description': 'Multiple KPIs underperforming - systematic review needed',
                'impact_score': len(analysis_results['critical_issues']) * 10,
                'urgency': 'critical',
                'estimated_impact': 'Comprehensive business transformation required'
            })
        
        return opportunities
    
    async def initiate_autonomous_mission(self, opportunity: Dict) -> Dict:
        """Initiate autonomous mission based on identified opportunity"""
        mission = {
            'mission_id': f"wolf_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
            'opportunity': opportunity,
            'status': 'initiated',
            'created_at': datetime.utcnow().isoformat(),
            'priority': opportunity.get('urgency', 'medium'),
            'estimated_duration': '7-14 days',
            'success_metrics': []
        }
        
        # Add to mission queue
        self.mission_queue.append(mission)
        
        logger.info(f"Autonomous mission initiated: {mission['mission_id']}")
        return mission
    
    async def generate_cron_analysis(self):
        """Generate analysis for cron workflow execution"""
        analysis = await self.analyze_kpi_performance()
        
        # Store analysis history
        self.analysis_history.append(analysis)
        
        # Keep only last 100 analyses
        if len(self.analysis_history) > 100:
            self.analysis_history = self.analysis_history[-100:]
        
        # Auto-initiate missions for critical opportunities
        for opportunity in analysis['opportunities']:
            if opportunity.get('urgency') in ['critical', 'high']:
                mission = await self.initiate_autonomous_mission(opportunity)
                analysis['auto_initiated_missions'] = analysis.get('auto_initiated_missions', [])
                analysis['auto_initiated_missions'].append(mission['mission_id'])
        
        return analysis

# Initialize Wolf Protocol
wolf = WolfProtocolBI()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'agent_role': wolf.agent_role,
        'agent_id': wolf.agent_id,
        'primary_objective': wolf.primary_objective,
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/analyze', methods=['POST'])
async def run_analysis():
    """Run KPI analysis"""
    analysis = await wolf.analyze_kpi_performance()
    return jsonify(analysis)

@app.route('/cron/analyze', methods=['POST'])
async def cron_analysis():
    """Cron-triggered analysis with mission initiation"""
    analysis = await wolf.generate_cron_analysis()
    return jsonify(analysis)

@app.route('/missions', methods=['GET'])
def get_missions():
    """Get current mission queue"""
    return jsonify({
        'missions': wolf.mission_queue,
        'total_missions': len(wolf.mission_queue),
        'active_missions': len([m for m in wolf.mission_queue if m['status'] == 'initiated'])
    })

@app.route('/kpis', methods=['GET'])
def get_kpis():
    """Get KPI definitions"""
    return jsonify({
        'primary_kpis': wolf.primary_kpis,
        'alert_threshold': wolf.alert_threshold,
        'total_kpis': len(wolf.primary_kpis)
    })

@app.route('/history', methods=['GET'])
def get_analysis_history():
    """Get analysis history"""
    return jsonify({
        'analysis_history': wolf.analysis_history[-10:],  # Last 10 analyses
        'total_analyses': len(wolf.analysis_history)
    })

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify({
        'agent_role': wolf.agent_role,
        'agent_id': wolf.agent_id,
        'analysis_mode': wolf.analysis_mode,
        'alert_threshold': wolf.alert_threshold,
        'primary_objective': wolf.primary_objective,
        'database_host': wolf.db_host,
        'monitored_kpis': len(wolf.primary_kpis),
        'mission_queue_size': len(wolf.mission_queue),
        'analysis_history_size': len(wolf.analysis_history),
        'uptime': datetime.utcnow().isoformat(),
        'status': 'operational'
    })

if __name__ == '__main__':
    logger.info("Starting Wolf Protocol Business Intelligence Agent")
    app.run(host='0.0.0.0', port=8100, debug=True)
