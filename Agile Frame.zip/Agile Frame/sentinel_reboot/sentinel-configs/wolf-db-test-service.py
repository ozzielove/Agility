#!/usr/bin/env python3
"""
Wolf Protocol - Database Access Test Service
Testing analytical warehouse access with read-only credentials
"""

import os
import json
import asyncio
import psycopg2
import pandas as pd
from flask import Flask, jsonify, request
from datetime import datetime
import logging
from typing import Dict, List, Any

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('WolfDBTest')

app = Flask(__name__)

class WolfDatabaseTester:
    def __init__(self):
        self.agent_role = os.getenv('AGENT_ROLE', 'Wolf_BI_Protocol')
        self.agent_id = os.getenv('AGENT_ID', 'wolf-001')
        
        # Primary database credentials (admin access)
        self.db_host = os.getenv('DB_HOST', 'postgres-analytics')
        self.db_port = os.getenv('DB_PORT', '5432')
        self.db_name = os.getenv('DB_NAME', 'analytics_warehouse')
        self.db_user = os.getenv('DB_USER', 'wolf_protocol')
        self.db_password = os.getenv('DB_PASSWORD', 'secure_analytics_2025')
        
        # Read-only database credentials
        self.readonly_user = os.getenv('DB_READONLY_USER', 'wolf_readonly')
        self.readonly_password = os.getenv('DB_READONLY_PASSWORD', 'wolf_readonly_secure_2025')
        
        self.test_results = []
        
        logger.info(f"Wolf Database Tester initialized: {self.agent_id}")
        logger.info(f"Database: {self.db_host}:{self.db_port}/{self.db_name}")
        logger.info(f"Read-only user: {self.readonly_user}")
    
    def get_admin_connection(self):
        """Get admin database connection"""
        try:
            conn = psycopg2.connect(
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
                user=self.db_user,
                password=self.db_password
            )
            return conn
        except Exception as e:
            logger.error(f"Admin database connection failed: {e}")
            return None
    
    def get_readonly_connection(self):
        """Get read-only database connection"""
        try:
            conn = psycopg2.connect(
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
                user=self.readonly_user,
                password=self.readonly_password
            )
            return conn
        except Exception as e:
            logger.error(f"Read-only database connection failed: {e}")
            return None
    
    async def test_readonly_access(self) -> Dict[str, Any]:
        """Test read-only database access"""
        test_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'test_type': 'readonly_access',
            'agent_id': self.agent_id,
            'tests': []
        }
        
        # Test 1: Connection test
        conn_test = {
            'test_name': 'connection_test',
            'description': 'Test read-only database connection',
            'status': 'failed',
            'result': None,
            'error': None
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                conn_test['status'] = 'passed'
                conn_test['result'] = 'Successfully connected to database'
                conn.close()
                logger.info("Read-only connection test: PASSED")
            else:
                conn_test['error'] = 'Failed to establish connection'
                logger.error("Read-only connection test: FAILED")
        except Exception as e:
            conn_test['error'] = str(e)
            logger.error(f"Read-only connection test error: {e}")
        
        test_result['tests'].append(conn_test)
        
        # Test 2: KPI Metrics table count
        count_test = {
            'test_name': 'kpi_metrics_count',
            'description': 'COUNT(*) query on kpi_metrics table',
            'status': 'failed',
            'result': None,
            'error': None
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM kpi_metrics;")
                count = cursor.fetchone()[0]
                count_test['status'] = 'passed'
                count_test['result'] = f"kpi_metrics table contains {count} rows"
                cursor.close()
                conn.close()
                logger.info(f"KPI metrics count test: PASSED - {count} rows")
            else:
                count_test['error'] = 'No database connection available'
        except Exception as e:
            count_test['error'] = str(e)
            logger.error(f"KPI metrics count test error: {e}")
        
        test_result['tests'].append(count_test)
        
        # Test 3: Business opportunities table count
        biz_test = {
            'test_name': 'business_opportunities_count',
            'description': 'COUNT(*) query on business_opportunities table',
            'status': 'failed',
            'result': None,
            'error': None
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM business_opportunities;")
                count = cursor.fetchone()[0]
                biz_test['status'] = 'passed'
                biz_test['result'] = f"business_opportunities table contains {count} rows"
                cursor.close()
                conn.close()
                logger.info(f"Business opportunities count test: PASSED - {count} rows")
            else:
                biz_test['error'] = 'No database connection available'
        except Exception as e:
            biz_test['error'] = str(e)
            logger.error(f"Business opportunities count test error: {e}")
        
        test_result['tests'].append(biz_test)
        
        # Test 4: Sample analytical query
        analytics_test = {
            'test_name': 'analytical_query',
            'description': 'Complex analytical query with aggregations',
            'status': 'failed',
            'result': None,
            'error': None
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                cursor = conn.cursor()
                query = """
                    SELECT 
                        kpi_name,
                        COUNT(*) as measurement_count,
                        AVG(value) as avg_value,
                        AVG(target_value) as avg_target,
                        AVG((value - target_value) / target_value * 100) as avg_delta_percent
                    FROM kpi_metrics 
                    GROUP BY kpi_name 
                    ORDER BY kpi_name;
                """
                cursor.execute(query)
                results = cursor.fetchall()
                
                analytics_result = []
                for row in results:
                    analytics_result.append({
                        'kpi_name': row[0],
                        'measurement_count': row[1],
                        'avg_value': float(row[2]) if row[2] else 0,
                        'avg_target': float(row[3]) if row[3] else 0,
                        'avg_delta_percent': float(row[4]) if row[4] else 0
                    })
                
                analytics_test['status'] = 'passed'
                analytics_test['result'] = analytics_result
                cursor.close()
                conn.close()
                logger.info(f"Analytical query test: PASSED - {len(results)} KPIs analyzed")
            else:
                analytics_test['error'] = 'No database connection available'
        except Exception as e:
            analytics_test['error'] = str(e)
            logger.error(f"Analytical query test error: {e}")
        
        test_result['tests'].append(analytics_test)
        
        # Test 5: Write permission test (should fail)
        write_test = {
            'test_name': 'write_permission_test',
            'description': 'Attempt to INSERT (should fail for read-only user)',
            'status': 'failed',
            'result': None,
            'error': None
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO kpi_metrics (kpi_name, value, target_value) 
                    VALUES ('test_kpi', 100, 100);
                """)
                conn.commit()
                write_test['status'] = 'failed'
                write_test['error'] = 'Write operation succeeded - security violation!'
                cursor.close()
                conn.close()
                logger.error("Write permission test: FAILED - write succeeded when it should have failed")
            else:
                write_test['error'] = 'No database connection available'
        except Exception as e:
            # This should fail for read-only user
            write_test['status'] = 'passed'
            write_test['result'] = f"Write operation correctly denied: {str(e)}"
            logger.info(f"Write permission test: PASSED - write correctly denied")
        
        test_result['tests'].append(write_test)
        
        # Calculate overall test status
        passed_tests = len([t for t in test_result['tests'] if t['status'] == 'passed'])
        total_tests = len(test_result['tests'])
        test_result['overall_status'] = 'passed' if passed_tests == total_tests else 'partial'
        test_result['summary'] = f"{passed_tests}/{total_tests} tests passed"
        
        # Store test results
        self.test_results.append(test_result)
        
        return test_result
    
    async def verify_table_structure(self) -> Dict[str, Any]:
        """Verify database table structure"""
        structure_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'test_type': 'table_structure',
            'tables': {}
        }
        
        try:
            conn = self.get_readonly_connection()
            if conn:
                cursor = conn.cursor()
                
                # Get table information
                cursor.execute("""
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    ORDER BY table_name;
                """)
                
                tables = cursor.fetchall()
                
                for table in tables:
                    table_name = table[0]
                    
                    # Get column information
                    cursor.execute("""
                        SELECT column_name, data_type, is_nullable 
                        FROM information_schema.columns 
                        WHERE table_name = %s 
                        ORDER BY ordinal_position;
                    """, (table_name,))
                    
                    columns = cursor.fetchall()
                    
                    structure_result['tables'][table_name] = {
                        'columns': [
                            {
                                'name': col[0],
                                'type': col[1],
                                'nullable': col[2] == 'YES'
                            } for col in columns
                        ]
                    }
                
                cursor.close()
                conn.close()
                
                structure_result['status'] = 'success'
                logger.info(f"Table structure verification: SUCCESS - {len(tables)} tables found")
                
        except Exception as e:
            structure_result['status'] = 'failed'
            structure_result['error'] = str(e)
            logger.error(f"Table structure verification error: {e}")
        
        return structure_result

# Initialize the tester
tester = WolfDatabaseTester()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'agent_role': tester.agent_role,
        'agent_id': tester.agent_id,
        'database_host': tester.db_host,
        'readonly_user': tester.readonly_user,
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/test/database', methods=['POST'])
async def test_database_access():
    """Test database access with read-only credentials"""
    results = await tester.test_readonly_access()
    return jsonify(results)

@app.route('/test/structure', methods=['GET'])
async def test_table_structure():
    """Verify database table structure"""
    results = await tester.verify_table_structure()
    return jsonify(results)

@app.route('/test/results', methods=['GET'])
def get_test_results():
    """Get all test results"""
    return jsonify({
        'test_history': tester.test_results,
        'total_tests': len(tester.test_results)
    })

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify({
        'agent_role': tester.agent_role,
        'agent_id': tester.agent_id,
        'database_config': {
            'host': tester.db_host,
            'port': tester.db_port,
            'database': tester.db_name,
            'admin_user': tester.db_user,
            'readonly_user': tester.readonly_user
        },
        'test_results_count': len(tester.test_results),
        'uptime': datetime.utcnow().isoformat(),
        'status': 'operational'
    })

if __name__ == '__main__':
    logger.info("Starting Wolf Protocol Database Test Service")
    app.run(host='0.0.0.0', port=8102, debug=True)
