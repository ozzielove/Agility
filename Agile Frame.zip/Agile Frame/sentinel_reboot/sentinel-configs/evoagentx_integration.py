#!/usr/bin/env python3
"""
EvoAgentX Integration Module
Makes agents adaptable and self-evolving using the EvoAgentX framework
"""

import os
import json
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional
from dotenv import load_dotenv
from evoagentx.models import OpenAILLMConfig, OpenAILLM, LiteLLMConfig, LiteLLM
from evoagentx.workflow import WorkFlowGenerator, WorkFlowGraph, WorkFlow
from evoagentx.agents import AgentManager
from evoagentx.actions.code_extraction import CodeExtraction
from evoagentx.actions.code_verification import CodeVerification
from evoagentx.core.module_utils import extract_code_blocks
import logging

logger = logging.getLogger('EvoAgentX')

class EvoAgentXIntegration:
    """EvoAgentX integration for adaptive and self-evolving agents"""
    
    def __init__(self, agent_role: str, agent_id: str):
        self.agent_role = agent_role
        self.agent_id = agent_id
        
        # Load environment variables
        load_dotenv()
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        
        # LLM configurations
        self.openai_config = OpenAILLMConfig(
            model="gpt-4o-mini",
            openai_key=self.openai_api_key,
            stream=True,
            output_response=True,
            max_tokens=16000
        )
        
        self.verification_config = LiteLLMConfig(
            model="anthropic/claude-3-7-sonnet-20250219",
            anthropic_key=self.anthropic_api_key,
            stream=True,
            output_response=True,
            max_tokens=20000
        )
        
        # Initialize LLMs
        self.llm = OpenAILLM(config=self.openai_config)
        self.verification_llm = LiteLLM(config=self.verification_config)
        
        # Evolution tracking
        self.evolution_history = []
        self.current_capabilities = set()
        self.performance_metrics = {}
        
        logger.info(f"EvoAgentX integration initialized for {agent_role}:{agent_id}")
    
    async def evolve_capability(self, goal: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Evolve a new capability based on a goal"""
        evolution_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'goal': goal,
            'context': context or {},
            'agent_role': self.agent_role,
            'agent_id': self.agent_id,
            'status': 'initiated'
        }
        
        try:
            # Generate workflow for the goal
            wf_generator = WorkFlowGenerator(llm=self.llm)
            workflow_graph: WorkFlowGraph = wf_generator.generate_workflow(goal=goal)
            
            # Create agent manager and add agents
            agent_manager = AgentManager()
            agent_manager.add_agents_from_workflow(workflow_graph, llm_config=self.openai_config)
            
            # Execute workflow
            workflow = WorkFlow(graph=workflow_graph, agent_manager=agent_manager, llm=self.llm)
            output = workflow.execute()
            
            # Verify the output
            code_verifier = CodeVerification()
            verified_output = code_verifier.execute(
                llm=self.verification_llm,
                inputs={
                    "requirements": goal,
                    "code": output
                }
            ).verified_code
            
            evolution_result.update({
                'status': 'completed',
                'workflow_nodes': len(workflow_graph.nodes),
                'output_length': len(verified_output),
                'new_capability': self._extract_capability_name(goal),
                'verified_code': verified_output[:1000] + '...' if len(verified_output) > 1000 else verified_output
            })
            
            # Add to capabilities
            capability_name = self._extract_capability_name(goal)
            self.current_capabilities.add(capability_name)
            
            # Store evolution history
            self.evolution_history.append(evolution_result)
            
            logger.info(f"Successfully evolved capability: {capability_name}")
            
        except Exception as e:
            evolution_result.update({
                'status': 'failed',
                'error': str(e)
            })
            logger.error(f"Evolution failed: {e}")
        
        return evolution_result
    
    async def adapt_to_feedback(self, feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Adapt agent behavior based on feedback"""
        adaptation_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'feedback': feedback,
            'agent_role': self.agent_role,
            'adaptations_made': []
        }
        
        # Analyze feedback and determine adaptations
        if feedback.get('performance_score', 1.0) < 0.7:
            # Performance is low, need improvement
            improvement_goal = f"Improve {self.agent_role} performance in {feedback.get('area', 'general operations')}"
            evolution_result = await self.evolve_capability(improvement_goal, feedback)
            adaptation_result['adaptations_made'].append({
                'type': 'performance_improvement',
                'evolution_result': evolution_result
            })
        
        if feedback.get('new_requirements'):
            # New requirements detected
            for requirement in feedback['new_requirements']:
                requirement_goal = f"Implement {requirement} capability for {self.agent_role}"
                evolution_result = await self.evolve_capability(requirement_goal, feedback)
                adaptation_result['adaptations_made'].append({
                    'type': 'new_requirement',
                    'requirement': requirement,
                    'evolution_result': evolution_result
                })
        
        if feedback.get('error_patterns'):
            # Error patterns detected, need fixes
            for error_pattern in feedback['error_patterns']:
                fix_goal = f"Fix {error_pattern} error pattern in {self.agent_role}"
                evolution_result = await self.evolve_capability(fix_goal, feedback)
                adaptation_result['adaptations_made'].append({
                    'type': 'error_fix',
                    'error_pattern': error_pattern,
                    'evolution_result': evolution_result
                })
        
        return adaptation_result
    
    async def self_optimize(self) -> Dict[str, Any]:
        """Self-optimize based on performance metrics"""
        optimization_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'agent_role': self.agent_role,
            'optimizations': []
        }
        
        # Analyze current performance
        if self.performance_metrics:
            avg_response_time = self.performance_metrics.get('avg_response_time', 0)
            error_rate = self.performance_metrics.get('error_rate', 0)
            success_rate = self.performance_metrics.get('success_rate', 1.0)
            
            # Optimize response time if too slow
            if avg_response_time > 5.0:  # 5 seconds threshold
                optimization_goal = f"Optimize {self.agent_role} response time and performance"
                evolution_result = await self.evolve_capability(optimization_goal)
                optimization_result['optimizations'].append({
                    'type': 'response_time_optimization',
                    'current_time': avg_response_time,
                    'evolution_result': evolution_result
                })
            
            # Reduce error rate if too high
            if error_rate > 0.05:  # 5% threshold
                error_reduction_goal = f"Reduce error rate and improve reliability for {self.agent_role}"
                evolution_result = await self.evolve_capability(error_reduction_goal)
                optimization_result['optimizations'].append({
                    'type': 'error_reduction',
                    'current_error_rate': error_rate,
                    'evolution_result': evolution_result
                })
            
            # Improve success rate if too low
            if success_rate < 0.9:  # 90% threshold
                success_improvement_goal = f"Improve success rate and effectiveness for {self.agent_role}"
                evolution_result = await self.evolve_capability(success_improvement_goal)
                optimization_result['optimizations'].append({
                    'type': 'success_rate_improvement',
                    'current_success_rate': success_rate,
                    'evolution_result': evolution_result
                })
        
        return optimization_result
    
    async def generate_new_strategy(self, problem: str, constraints: List[str] = None) -> Dict[str, Any]:
        """Generate a new strategy for solving a problem"""
        strategy_goal = f"Generate innovative strategy for {self.agent_role} to solve: {problem}"
        
        if constraints:
            strategy_goal += f" with constraints: {', '.join(constraints)}"
        
        evolution_result = await self.evolve_capability(strategy_goal, {
            'problem': problem,
            'constraints': constraints or [],
            'type': 'strategy_generation'
        })
        
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'problem': problem,
            'constraints': constraints,
            'strategy_evolution': evolution_result,
            'agent_role': self.agent_role
        }
    
    def update_performance_metrics(self, metrics: Dict[str, float]):
        """Update performance metrics for self-optimization"""
        self.performance_metrics.update(metrics)
        self.performance_metrics['last_updated'] = datetime.utcnow().isoformat()
    
    def get_evolution_status(self) -> Dict[str, Any]:
        """Get current evolution status"""
        return {
            'agent_role': self.agent_role,
            'agent_id': self.agent_id,
            'current_capabilities': list(self.current_capabilities),
            'evolution_count': len(self.evolution_history),
            'performance_metrics': self.performance_metrics,
            'last_evolution': self.evolution_history[-1] if self.evolution_history else None,
            'evoagentx_enabled': bool(self.openai_api_key and self.anthropic_api_key)
        }
    
    def _extract_capability_name(self, goal: str) -> str:
        """Extract capability name from goal"""
        # Simple extraction - could be enhanced with NLP
        words = goal.lower().split()
        action_words = ['improve', 'optimize', 'enhance', 'fix', 'implement', 'generate']
        
        for i, word in enumerate(words):
            if word in action_words and i + 1 < len(words):
                return '_'.join(words[i:i+3])  # Take action + next 2 words
        
        return '_'.join(words[:3])  # First 3 words as fallback

class AgentEvolutionManager:
    """Manages evolution across multiple agents"""
    
    def __init__(self):
        self.agents = {}
        self.cross_agent_learnings = []
    
    def register_agent(self, agent_role: str, agent_id: str) -> EvoAgentXIntegration:
        """Register an agent for evolution management"""
        evo_integration = EvoAgentXIntegration(agent_role, agent_id)
        self.agents[f"{agent_role}:{agent_id}"] = evo_integration
        return evo_integration
    
    async def cross_agent_learning(self, source_agent: str, target_agents: List[str], capability: str) -> Dict[str, Any]:
        """Share learnings between agents"""
        learning_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'source_agent': source_agent,
            'target_agents': target_agents,
            'capability': capability,
            'transfers': []
        }
        
        if source_agent in self.agents:
            source_evo = self.agents[source_agent]
            
            for target_agent in target_agents:
                if target_agent in self.agents:
                    target_evo = self.agents[target_agent]
                    
                    # Transfer capability
                    transfer_goal = f"Adapt {capability} from {source_agent} for {target_agent}"
                    evolution_result = await target_evo.evolve_capability(transfer_goal, {
                        'source_agent': source_agent,
                        'capability_transfer': True
                    })
                    
                    learning_result['transfers'].append({
                        'target_agent': target_agent,
                        'evolution_result': evolution_result
                    })
        
        self.cross_agent_learnings.append(learning_result)
        return learning_result
    
    def get_system_evolution_status(self) -> Dict[str, Any]:
        """Get evolution status for all agents"""
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'total_agents': len(self.agents),
            'agents': {agent_key: agent.get_evolution_status() for agent_key, agent in self.agents.items()},
            'cross_agent_learnings': len(self.cross_agent_learnings),
            'system_capabilities': list(set().union(*[agent.current_capabilities for agent in self.agents.values()]))
        }

# Global evolution manager instance
evolution_manager = AgentEvolutionManager()

def get_evolution_manager() -> AgentEvolutionManager:
    """Get the global evolution manager"""
    return evolution_manager
