#!/usr/bin/env python3
"""
Smoke Test for Sprint Burndown Chart Generator (Step 8)
Tests all core functionality of the burndown chart system
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'zeus_core'))

from burndown_chart import BurndownChartGenerator, notify_channel
from datetime import datetime, timedelta
import json
import tempfile
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

def test_ideal_line_calculation():
    """Test ideal burndown line calculation"""
    print("\n🧮 Testing ideal line calculation...")
    
    generator = BurndownChartGenerator()
    
    # Test case 1: 100 points over 168 hours (1 week)
    ideal_line = generator.calculate_ideal_line(100, 168)
    
    assert len(ideal_line) == 169, f"Expected 169 points, got {len(ideal_line)}"
    assert ideal_line[0] == 100, f"Expected start at 100, got {ideal_line[0]}"
    assert abs(ideal_line[-1]) < 0.01, f"Expected end near 0, got {ideal_line[-1]}"
    
    # Test linear progression
    mid_point = ideal_line[84]  # Halfway point
    expected_mid = 50
    assert abs(mid_point - expected_mid) < 1, f"Expected ~50 at midpoint, got {mid_point}"
    
    print("✅ Ideal line calculation: PASS")
    return True

def test_actual_remaining_calculation():
    """Test actual remaining points calculation"""
    print("\n📊 Testing actual remaining calculation...")
    
    generator = BurndownChartGenerator()
    
    # Sample backlog items
    backlog_items = [
        {'id': 'TASK-1', 'points': 8, 'status': 'completed', 'updated_at': datetime(2025, 7, 19, 10, 0)},
        {'id': 'TASK-2', 'points': 5, 'status': 'in_progress', 'updated_at': datetime(2025, 7, 19, 9, 0)},
        {'id': 'TASK-3', 'points': 13, 'status': 'open', 'updated_at': datetime(2025, 7, 19, 8, 0)},
        {'id': 'TASK-4', 'points': 3, 'status': 'completed', 'updated_at': datetime(2025, 7, 19, 14, 0)}
    ]
    
    # Test at different timestamps
    timestamp1 = datetime(2025, 7, 19, 9, 30)  # After TASK-2 started
    remaining1 = generator.calculate_actual_remaining(backlog_items, timestamp1)
    expected1 = 5 + 13  # in_progress + open
    assert remaining1 == expected1, f"Expected {expected1}, got {remaining1}"
    
    timestamp2 = datetime(2025, 7, 19, 15, 0)  # After all updates
    remaining2 = generator.calculate_actual_remaining(backlog_items, timestamp2)
    expected2 = 5 + 13  # Still in_progress + open
    assert remaining2 == expected2, f"Expected {expected2}, got {remaining2}"
    
    print("✅ Actual remaining calculation: PASS")
    return True

def test_chart_data_generation():
    """Test complete chart data generation"""
    print("\n📈 Testing chart data generation...")
    
    generator = BurndownChartGenerator()
    
    # Sample sprint object
    sprint_obj = {
        'id': 'SPRINT-TEST-001',
        'start_date': '2025-07-19T09:00:00',
        'end_date': '2025-07-19T17:00:00',  # 8 hour sprint for testing
        'total_points': 50
    }
    
    # Sample backlog updates
    backlog_updates = [
        {'id': 'TASK-1', 'points': 10, 'status': 'completed', 'updated_at': datetime(2025, 7, 19, 11, 0)},
        {'id': 'TASK-2', 'points': 15, 'status': 'in_progress', 'updated_at': datetime(2025, 7, 19, 10, 0)},
        {'id': 'TASK-3', 'points': 25, 'status': 'open', 'updated_at': datetime(2025, 7, 19, 9, 0)}
    ]
    
    timestamps, ideal_line, actual_remaining = generator.generate_chart_data(sprint_obj, backlog_updates)
    
    # Verify data structure
    assert len(timestamps) == len(ideal_line) == len(actual_remaining), "Data arrays must be same length"
    assert len(timestamps) == 9, f"Expected 9 hourly points, got {len(timestamps)}"
    
    # Verify ideal line
    assert ideal_line[0] == 50, f"Expected ideal start at 50, got {ideal_line[0]}"
    assert abs(ideal_line[-1]) < 0.01, f"Expected ideal end near 0, got {ideal_line[-1]}"
    
    # Verify timestamps
    assert timestamps[0] == datetime(2025, 7, 19, 9, 0), "Start timestamp incorrect"
    assert timestamps[-1] == datetime(2025, 7, 19, 17, 0), "End timestamp incorrect"
    
    print("✅ Chart data generation: PASS")
    return True

def test_chart_rendering():
    """Test matplotlib chart rendering"""
    print("\n🎨 Testing chart rendering...")
    
    generator = BurndownChartGenerator()
    
    # Generate test data
    timestamps = [datetime(2025, 7, 19, 9, 0) + timedelta(hours=i) for i in range(9)]
    ideal_line = [50 - (50 * i / 8) for i in range(9)]
    actual_remaining = [50, 45, 40, 35, 30, 25, 20, 15, 10]
    
    # Render chart
    chart_path = generator.render_chart(timestamps, ideal_line, actual_remaining, 'TEST-001')
    
    # Verify file was created
    assert os.path.exists(chart_path), f"Chart file not created: {chart_path}"
    assert chart_path.endswith('.png'), f"Expected PNG file, got {chart_path}"
    
    # Check file size (should be reasonable for a chart)
    file_size = os.path.getsize(chart_path)
    assert file_size > 1000, f"Chart file too small: {file_size} bytes"
    assert file_size < 1000000, f"Chart file too large: {file_size} bytes"
    
    print(f"✅ Chart rendering: PASS (file: {chart_path}, size: {file_size} bytes)")
    
    # Cleanup
    os.remove(chart_path)
    return True

def test_csv_data_persistence():
    """Test CSV data saving"""
    print("\n💾 Testing CSV data persistence...")
    
    generator = BurndownChartGenerator()
    
    # Generate test data
    timestamps = [datetime(2025, 7, 19, 9, 0) + timedelta(hours=i) for i in range(5)]
    ideal_line = [40, 30, 20, 10, 0]
    actual_remaining = [40, 35, 25, 15, 5]
    
    # Save CSV
    csv_path = generator.save_csv_data(timestamps, ideal_line, actual_remaining, 'TEST-CSV')
    
    # Verify file was created
    assert os.path.exists(csv_path), f"CSV file not created: {csv_path}"
    assert csv_path.endswith('.csv'), f"Expected CSV file, got {csv_path}"
    
    # Read and verify content
    with open(csv_path, 'r') as f:
        content = f.read()
        assert 'timestamp,ideal_remaining,actual_remaining' in content, "CSV header missing"
        assert '2025-07-19 09:00:00' in content, "Timestamp data missing"
        assert '40' in content, "Point data missing"
    
    print(f"✅ CSV data persistence: PASS (file: {csv_path})")
    
    # Cleanup
    os.remove(csv_path)
    return True

def test_end_to_end_generation():
    """Test complete end-to-end burndown chart generation"""
    print("\n🔄 Testing end-to-end generation...")
    
    generator = BurndownChartGenerator()
    
    # Complete sprint data
    sprint_obj = {
        'id': 'SPRINT-E2E-001',
        'start_date': '2025-07-19T09:00:00',
        'end_date': '2025-07-21T17:00:00',  # 2-day sprint
        'total_points': 80
    }
    
    # Realistic backlog updates
    backlog_updates = [
        {'id': 'STORY-1', 'points': 20, 'status': 'completed', 'updated_at': datetime(2025, 7, 19, 15, 0)},
        {'id': 'STORY-2', 'points': 15, 'status': 'completed', 'updated_at': datetime(2025, 7, 20, 11, 0)},
        {'id': 'STORY-3', 'points': 25, 'status': 'in_progress', 'updated_at': datetime(2025, 7, 20, 9, 0)},
        {'id': 'STORY-4', 'points': 20, 'status': 'open', 'updated_at': datetime(2025, 7, 19, 9, 0)}
    ]
    
    # Generate complete burndown chart
    result = generator.generate_burndown_chart(sprint_obj, backlog_updates)
    
    # Verify result structure
    assert result['status'] == 'success', f"Generation failed: {result.get('error', 'Unknown error')}"
    assert 'chart_url' in result, "Chart URL missing from result"
    assert 'csv_url' in result, "CSV URL missing from result"
    assert 'local_chart' in result, "Local chart path missing"
    assert 'local_csv' in result, "Local CSV path missing"
    
    # Verify files exist
    assert os.path.exists(result['local_chart']), f"Chart file missing: {result['local_chart']}"
    assert os.path.exists(result['local_csv']), f"CSV file missing: {result['local_csv']}"
    
    print(f"✅ End-to-end generation: PASS")
    print(f"   Chart: {result['local_chart']}")
    print(f"   CSV: {result['local_csv']}")
    
    # Cleanup
    os.remove(result['local_chart'])
    os.remove(result['local_csv'])
    
    return True

def test_notification_system():
    """Test channel notification functionality"""
    print("\n📢 Testing notification system...")
    
    chart_info = {
        'chart_url': 's3://charts/SPRINT-001/burndown.png',
        'csv_url': 's3://charts/SPRINT-001/burndown.csv',
        'status': 'success'
    }
    
    message = notify_channel(chart_info, 'SPRINT-001')
    
    # Verify notification content
    assert 'SPRINT-001' in message, "Sprint ID missing from notification"
    assert 's3://charts' in message, "S3 URL missing from notification"
    assert 'burndown.png' in message, "Chart reference missing"
    
    print(f"✅ Notification system: PASS")
    print(f"   Message: {message.replace(chr(10), ' | ')}")
    
    return True

def run_smoke_tests():
    """Run all smoke tests for burndown chart generator"""
    print("🚀 Starting Sprint Burndown Chart Generator Smoke Tests")
    print("=" * 60)
    
    tests = [
        test_ideal_line_calculation,
        test_actual_remaining_calculation,
        test_chart_data_generation,
        test_chart_rendering,
        test_csv_data_persistence,
        test_end_to_end_generation,
        test_notification_system
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ {test.__name__}: FAIL - {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All burndown chart tests passed! System ready for production.")
        return True
    else:
        print(f"⚠️  {failed} test(s) failed. Please review and fix issues.")
        return False

if __name__ == '__main__':
    success = run_smoke_tests()
    sys.exit(0 if success else 1)
