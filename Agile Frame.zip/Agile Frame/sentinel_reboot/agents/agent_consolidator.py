#!/usr/bin/env python3
"""
Agent Consolidation and Management System
Consolidates all quantum agents with Zeus protocol integration
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Any
import logging

class AgentConsolidator:
    def __init__(self, agents_dir: str = "./agents"):
        self.agents_dir = Path(agents_dir)
        self.consolidated_agents = {}
        self.setup_logging()
        
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('agent_consolidation.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def load_quantum_agents(self) -> Dict[str, Any]:
        """Load all quantum agent JSON files"""
        quantum_agents = {}
        
        for json_file in self.agents_dir.glob("*_agent_quantum.json"):
            try:
                with open(json_file, 'r') as f:
                    agent_data = json.load(f)
                    agent_name = json_file.stem.replace('_agent_quantum', '')
                    quantum_agents[agent_name] = agent_data
                    self.logger.info(f"Loaded quantum agent: {agent_name}")
            except Exception as e:
                self.logger.error(f"Failed to load {json_file}: {e}")
                
        return quantum_agents
        
    def load_zeus_agent(self) -> Dict[str, Any]:
        """Load Zeus unified agent"""
        zeus_file = self.agents_dir / "zeus_unified.json"
        if zeus_file.exists():
            try:
                with open(zeus_file, 'r') as f:
                    zeus_data = json.load(f)
                    self.logger.info("Loaded Zeus unified agent")
                    return zeus_data
            except Exception as e:
                self.logger.error(f"Failed to load Zeus agent: {e}")
        return {}
        
    def consolidate_agents(self) -> Dict[str, Any]:
        """Consolidate all agents into unified structure"""
        quantum_agents = self.load_quantum_agents()
        zeus_agent = self.load_zeus_agent()
        
        consolidated = {
            "swarm_metadata": {
                "total_agents": len(quantum_agents) + (1 if zeus_agent else 0),
                "quantum_agents": len(quantum_agents),
                "zeus_protocol": bool(zeus_agent),
                "consolidation_timestamp": self._get_timestamp()
            },
            "zeus_protocol": zeus_agent,
            "quantum_agents": quantum_agents,
            "agent_registry": self._create_agent_registry(quantum_agents, zeus_agent)
        }
        
        self.consolidated_agents = consolidated
        return consolidated
        
    def _create_agent_registry(self, quantum_agents: Dict, zeus_agent: Dict) -> Dict:
        """Create agent registry for coordination"""
        registry = {}
        
        # Add Zeus as coordinator
        if zeus_agent:
            registry["zeus"] = {
                "role": "ScrumMaster",
                "type": "coordinator",
                "status": "active",
                "capabilities": ["scrum_facilitation", "impediment_removal", "swarm_optimization"]
            }
            
        # Add quantum agents
        for agent_name, agent_data in quantum_agents.items():
            registry[agent_name] = {
                "role": agent_data.get("role", "specialist"),
                "type": "quantum",
                "status": "active",
                "capabilities": agent_data.get("capabilities", [])
            }
            
        return registry
        
    def _get_timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()
        
    def save_consolidated_structure(self, output_file: str = "consolidated_agents.json"):
        """Save consolidated agent structure"""
        output_path = self.agents_dir / output_file
        
        with open(output_path, 'w') as f:
            json.dump(self.consolidated_agents, f, indent=2)
            
        self.logger.info(f"Consolidated structure saved to {output_path}")
        
    def remove_duplicates(self):
        """Remove duplicate agent files"""
        seen_agents = set()
        duplicates = []
        
        for json_file in self.agents_dir.glob("*.json"):
            agent_name = json_file.stem.replace('_agent_quantum', '').replace('_unified', '')
            
            if agent_name in seen_agents:
                duplicates.append(json_file)
            else:
                seen_agents.add(agent_name)
                
        for duplicate in duplicates:
            self.logger.info(f"Removing duplicate: {duplicate}")
            duplicate.unlink()
            
    def generate_agent_manifest(self) -> str:
        """Generate comprehensive agent manifest"""
        if not self.consolidated_agents:
            self.consolidate_agents()
            
        manifest = []
        manifest.append("# SENTINEL SWARM AGENT MANIFEST")
        manifest.append("=" * 50)
        manifest.append(f"Total Agents: {self.consolidated_agents['swarm_metadata']['total_agents']}")
        manifest.append(f"Quantum Agents: {self.consolidated_agents['swarm_metadata']['quantum_agents']}")
        manifest.append(f"Zeus Protocol: {self.consolidated_agents['swarm_metadata']['zeus_protocol']}")
        manifest.append("")
        
        manifest.append("## AGENT REGISTRY")
        manifest.append("-" * 30)
        
        for agent_name, agent_info in self.consolidated_agents['agent_registry'].items():
            manifest.append(f"**{agent_name.upper()}**")
            manifest.append(f"  Role: {agent_info['role']}")
            manifest.append(f"  Type: {agent_info['type']}")
            manifest.append(f"  Status: {agent_info['status']}")
            manifest.append(f"  Capabilities: {', '.join(agent_info['capabilities'])}")
            manifest.append("")
            
        return "\n".join(manifest)
        
    def run_consolidation(self):
        """Execute complete consolidation process"""
        self.logger.info("Starting agent consolidation process...")
        
        # Remove duplicates first
        self.remove_duplicates()
        
        # Consolidate agents
        consolidated = self.consolidate_agents()
        
        # Save consolidated structure
        self.save_consolidated_structure()
        
        # Generate manifest
        manifest = self.generate_agent_manifest()
        
        # Save manifest
        manifest_path = self.agents_dir / "AGENT_MANIFEST.md"
        with open(manifest_path, 'w') as f:
            f.write(manifest)
            
        self.logger.info(f"Agent consolidation complete. Manifest saved to {manifest_path}")
        
        return consolidated

if __name__ == "__main__":
    consolidator = AgentConsolidator()
    result = consolidator.run_consolidation()
    
    print(f"\nConsolidation Summary:")
    print(f"Total Agents: {result['swarm_metadata']['total_agents']}")
    print(f"Quantum Agents: {result['swarm_metadata']['quantum_agents']}")
    print(f"Zeus Protocol: {result['swarm_metadata']['zeus_protocol']}")
