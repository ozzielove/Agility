# COMPREHENSIVE TESTING REPORT
==================================================
Generated: 2025-07-13T03:22:39.363654
Total Agents Tested: 23

## FUNCTIONAL TESTING RESULTS
------------------------------
**agent_initialization:** 23/23 passed
  Failed: 17_quant_agent_quantum, 9_helix_agent_quantum, 11_janus_agent_quantum, zeus_unified, 16_paladin_agent_quantum...
**agent_communication:** 23/23 passed
  Failed: 12_loki_agent_quantum, 7_echo_agent_quantum, 5_chronos_agent_quantum, 6_datus_agent_quantum, 18_themis_agent_quantum...

## UNIT TESTING RESULTS
------------------------------
**agent_modules:** 0/23 passed
**configuration_validation:** 23/23 passed

## INTEGRATION TESTING RESULTS
------------------------------
**agent_dependencies:** 23/23 passed
**service_connectivity:** 4/4 passed

## REGRESSION TESTING RESULTS
------------------------------
**agent_compatibility:** 23/23 passed
  Failed: 12_loki_agent_quantum, 7_echo_agent_quantum, 5_chronos_agent_quantum, 6_datus_agent_quantum, 18_themis_agent_quantum...

## SMOKE TESTING RESULTS
------------------------------
**critical_agents:** 4/4 passed
  Failed: zeus_unified, hermes

## PERFORMANCE TESTING RESULTS
------------------------------
**agent_loading:** 23/23 passed
**memory_usage:** 23/23 passed

## LOAD TESTING RESULTS
------------------------------
**concurrent_access:** 0/5 passed

## STRESS TESTING RESULTS
------------------------------
**maximum_load:**
  Operations: 49204
  Errors: 0
  Avg Response Time: 0.0006s
  Max Memory: 36.03MB

## OVERALL SUMMARY
Total Tests: 197
Passed: 169
Failed: 28
Success Rate: 85.8%