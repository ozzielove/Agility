"""
Product Backlog Management Module for Zeus Agent
Implements comprehensive backlog management with mission objective parsing
"""

import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum

class BacklogItemStatus(Enum):
    NEW = "new"
    READY = "ready"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    BLOCKED = "blocked"

class BacklogItemPriority(Enum):
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4

class ProductBacklogManager:
    """
    Manages the Product Backlog with mission objective parsing capabilities
    Implements prioritization, estimation, and status tracking
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.backlog_items = {}
        self.next_id = 1
        self.state_of_union_document = None
        
    def parse_mission_objectives(self, state_of_union_doc: str) -> List[Dict[str, Any]]:
        """
        Parse mission objectives from State of the Union document
        into prioritized actionable tasks
        """
        self.logger.info("Parsing mission objectives from State of Union document")
        
        # Parse document and extract objectives
        objectives = self._extract_objectives_from_document(state_of_union_doc)
        
        # Convert to backlog items
        backlog_items = []
        for obj in objectives:
            item = self.create_backlog_item(
                description=obj.get('description', ''),
                value=obj.get('business_value', 0),
                effort=obj.get('effort_estimate', 0),
                priority=obj.get('priority', BacklogItemPriority.MEDIUM)
            )
            backlog_items.append(item)
        
        return backlog_items
    
    def create_backlog_item(self, description: str, value: int, effort: int, 
                          priority: BacklogItemPriority = BacklogItemPriority.MEDIUM,
                          acceptance_criteria: List[str] = None) -> Dict[str, Any]:
        """
        Create a new backlog item with required fields:
        ID, description, value (BV), effort (points), and status
        """
        item_id = f"PBI-{self.next_id:04d}"
        self.next_id += 1
        
        backlog_item = {
            'id': item_id,
            'description': description,
            'value': value,  # Business Value
            'effort': effort,  # Story Points
            'status': BacklogItemStatus.NEW.value,
            'priority': priority.value,
            'acceptance_criteria': acceptance_criteria or [],
            'created_date': datetime.now().isoformat(),
            'updated_date': datetime.now().isoformat(),
            'sprint_assignment': None,
            'dependencies': [],
            'tags': [],
            'assignee': None
        }
        
        self.backlog_items[item_id] = backlog_item
        self.logger.info(f"Created backlog item {item_id}: {description}")
        
        return backlog_item
    
    def prioritize_backlog(self) -> List[Dict[str, Any]]:
        """
        Prioritize backlog items using value/effort ratio and priority
        """
        items = list(self.backlog_items.values())
        
        # Calculate priority score (higher is better)
        for item in items:
            value_effort_ratio = item['value'] / max(item['effort'], 1)
            priority_weight = 5 - item['priority']  # Higher priority = lower number
            item['priority_score'] = value_effort_ratio * priority_weight
        
        # Sort by priority score (descending)
        prioritized_items = sorted(items, key=lambda x: x['priority_score'], reverse=True)
        
        self.logger.info(f"Prioritized {len(prioritized_items)} backlog items")
        return prioritized_items
    
    def get_ready_items(self) -> List[Dict[str, Any]]:
        """Get items that are ready for sprint planning"""
        ready_items = [
            item for item in self.backlog_items.values()
            if item['status'] == BacklogItemStatus.READY.value
        ]
        return ready_items
    
    def update_item_status(self, item_id: str, new_status: BacklogItemStatus) -> bool:
        """Update the status of a backlog item"""
        if item_id in self.backlog_items:
            self.backlog_items[item_id]['status'] = new_status.value
            self.backlog_items[item_id]['updated_date'] = datetime.now().isoformat()
            self.logger.info(f"Updated {item_id} status to {new_status.value}")
            return True
        return False
    
    def assign_to_sprint(self, item_id: str, sprint_id: str) -> bool:
        """Assign backlog item to a sprint"""
        if item_id in self.backlog_items:
            self.backlog_items[item_id]['sprint_assignment'] = sprint_id
            self.backlog_items[item_id]['status'] = BacklogItemStatus.IN_PROGRESS.value
            self.backlog_items[item_id]['updated_date'] = datetime.now().isoformat()
            self.logger.info(f"Assigned {item_id} to sprint {sprint_id}")
            return True
        return False
    
    def get_backlog_metrics(self) -> Dict[str, Any]:
        """Get backlog health metrics"""
        total_items = len(self.backlog_items)
        status_counts = {}
        
        for status in BacklogItemStatus:
            count = len([item for item in self.backlog_items.values() 
                        if item['status'] == status.value])
            status_counts[status.value] = count
        
        total_value = sum(item['value'] for item in self.backlog_items.values())
        total_effort = sum(item['effort'] for item in self.backlog_items.values())
        
        return {
            'total_items': total_items,
            'status_distribution': status_counts,
            'total_business_value': total_value,
            'total_effort_estimate': total_effort,
            'average_item_value': total_value / max(total_items, 1),
            'average_item_effort': total_effort / max(total_items, 1)
        }
    
    def _extract_objectives_from_document(self, document: str) -> List[Dict[str, Any]]:
        """
        Extract mission objectives from State of Union document
        This is a simplified parser - in production would use NLP
        """
        # Simplified parsing logic
        objectives = []
        
        # Split document into sections and extract actionable items
        lines = document.split('\n')
        current_objective = {}
        
        for line in lines:
            line = line.strip()
            if line.startswith('Objective:') or line.startswith('Goal:'):
                if current_objective:
                    objectives.append(current_objective)
                current_objective = {
                    'description': line.replace('Objective:', '').replace('Goal:', '').strip(),
                    'business_value': 5,  # Default value
                    'effort_estimate': 8,  # Default effort
                    'priority': BacklogItemPriority.MEDIUM
                }
            elif line.startswith('Priority:') and current_objective:
                priority_text = line.replace('Priority:', '').strip().lower()
                if 'critical' in priority_text or 'high' in priority_text:
                    current_objective['priority'] = BacklogItemPriority.HIGH
                elif 'low' in priority_text:
                    current_objective['priority'] = BacklogItemPriority.LOW
        
        if current_objective:
            objectives.append(current_objective)
        
        return objectives
    
    def export_backlog(self) -> str:
        """Export backlog as JSON"""
        return json.dumps(self.backlog_items, indent=2)
    
    def import_backlog(self, backlog_json: str) -> bool:
        """Import backlog from JSON"""
        try:
            imported_items = json.loads(backlog_json)
            self.backlog_items.update(imported_items)
            # Update next_id to avoid conflicts
            max_id = max([int(item_id.split('-')[1]) for item_id in imported_items.keys()], default=0)
            self.next_id = max(self.next_id, max_id + 1)
            return True
        except Exception as e:
            self.logger.error(f"Failed to import backlog: {e}")
            return False

if __name__ == "__main__":
    # Example usage
    pbm = ProductBacklogManager()
    
    # Create sample backlog items
    pbm.create_backlog_item(
        description="Implement user authentication system",
        value=8,
        effort=13,
        priority=BacklogItemPriority.HIGH
    )
    
    pbm.create_backlog_item(
        description="Add dashboard analytics",
        value=5,
        effort=8,
        priority=BacklogItemPriority.MEDIUM
    )
    
    # Get prioritized backlog
    prioritized = pbm.prioritize_backlog()
    print(f"Prioritized backlog: {len(prioritized)} items")
    
    # Get metrics
    metrics = pbm.get_backlog_metrics()
    print(f"Backlog metrics: {metrics}")
