"""
Sprint Planning Module for Zeus Agent
Implements Sprint Backlog creation and capacity planning
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from enum import Enum

class SprintStatus(Enum):
    PLANNING = "planning"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class SprintPlanner:
    """
    Sprint Planning Module for creating Sprint Backlogs
    Selects high-priority items that can be completed within Sprint duration
    """
    
    def __init__(self, default_sprint_duration_hours: int = 12):
        self.logger = logging.getLogger(__name__)
        self.default_sprint_duration = default_sprint_duration_hours
        self.sprints = {}
        self.next_sprint_id = 1
        
    def create_sprint_backlog(self, product_backlog: List[Dict[str, Any]], 
                            team_capacity: int,
                            sprint_duration_hours: Optional[int] = None) -> Dict[str, Any]:
        """
        Create Sprint Backlog by selecting high-priority items
        that can be completed within the defined Sprint duration
        """
        duration = sprint_duration_hours or self.default_sprint_duration
        sprint_id = f"SPRINT-{self.next_sprint_id:03d}"
        self.next_sprint_id += 1
        
        self.logger.info(f"Creating Sprint Backlog for {sprint_id} with {duration}h duration")
        
        # Calculate available capacity
        available_capacity = self._calculate_available_capacity(team_capacity, duration)
        
        # Select items for sprint
        selected_items = self._select_sprint_items(product_backlog, available_capacity)
        
        # Create sprint goal
        sprint_goal = self._generate_sprint_goal(selected_items)
        
        # Create sprint backlog
        sprint_backlog = {
            'sprint_id': sprint_id,
            'sprint_goal': sprint_goal,
            'duration_hours': duration,
            'start_date': datetime.now().isoformat(),
            'end_date': (datetime.now() + timedelta(hours=duration)).isoformat(),
            'status': SprintStatus.PLANNING.value,
            'team_capacity': team_capacity,
            'available_capacity': available_capacity,
            'committed_items': selected_items,
            'total_committed_effort': sum(item['effort'] for item in selected_items),
            'created_date': datetime.now().isoformat(),
            'metrics': {
                'planned_velocity': sum(item['effort'] for item in selected_items),
                'capacity_utilization': 0.0,
                'scope_changes': 0,
                'items_completed': 0,
                'items_carried_over': 0
            }
        }
        
        self.sprints[sprint_id] = sprint_backlog
        self.logger.info(f"Created Sprint Backlog {sprint_id} with {len(selected_items)} items")
        
        return sprint_backlog
    
    def _calculate_available_capacity(self, team_capacity: int, duration_hours: int) -> int:
        """
        Calculate available team capacity considering:
        - Team size
        - Sprint duration
        - Capacity buffer (20% for meetings, interruptions)
        """
        # Assume 8 hours per day per team member
        total_hours = team_capacity * duration_hours
        
        # Apply 20% buffer for meetings, interruptions, etc.
        available_hours = total_hours * 0.8
        
        # Convert to story points (assuming 1 story point = 1 hour)
        available_capacity = int(available_hours)
        
        self.logger.debug(f"Calculated capacity: {available_capacity} points for {team_capacity} team members")
        return available_capacity
    
    def _select_sprint_items(self, product_backlog: List[Dict[str, Any]], 
                           available_capacity: int) -> List[Dict[str, Any]]:
        """
        Select items for sprint based on priority and capacity
        """
        selected_items = []
        remaining_capacity = available_capacity
        
        # Sort backlog by priority (assuming higher priority_score is better)
        sorted_backlog = sorted(product_backlog, 
                              key=lambda x: x.get('priority_score', 0), 
                              reverse=True)
        
        for item in sorted_backlog:
            item_effort = item.get('effort', 0)
            
            # Check if item fits in remaining capacity
            if item_effort <= remaining_capacity:
                # Check if item is ready for sprint
                if item.get('status') in ['new', 'ready']:
                    selected_items.append(item.copy())
                    remaining_capacity -= item_effort
                    self.logger.debug(f"Selected item {item['id']} (effort: {item_effort})")
            
            # Stop if capacity is exhausted
            if remaining_capacity <= 0:
                break
        
        self.logger.info(f"Selected {len(selected_items)} items using {available_capacity - remaining_capacity}/{available_capacity} capacity")
        return selected_items
    
    def _generate_sprint_goal(self, selected_items: List[Dict[str, Any]]) -> str:
        """
        Generate a cohesive Sprint Goal based on selected items
        """
        if not selected_items:
            return "No items selected for this sprint"
        
        # Simple goal generation based on common themes
        descriptions = [item['description'] for item in selected_items]
        
        # Extract common keywords (simplified approach)
        common_themes = self._extract_common_themes(descriptions)
        
        if common_themes:
            goal = f"Deliver {', '.join(common_themes[:3])} functionality to enhance user experience"
        else:
            goal = f"Complete {len(selected_items)} high-priority backlog items"
        
        return goal
    
    def _extract_common_themes(self, descriptions: List[str]) -> List[str]:
        """Extract common themes from item descriptions"""
        # Simplified theme extraction
        common_words = ['user', 'system', 'data', 'interface', 'security', 'performance']
        themes = []
        
        for word in common_words:
            if any(word.lower() in desc.lower() for desc in descriptions):
                themes.append(word)
        
        return themes
    
    def start_sprint(self, sprint_id: str) -> bool:
        """Start a planned sprint"""
        if sprint_id in self.sprints:
            sprint = self.sprints[sprint_id]
            if sprint['status'] == SprintStatus.PLANNING.value:
                sprint['status'] = SprintStatus.ACTIVE.value
                sprint['actual_start_date'] = datetime.now().isoformat()
                self.logger.info(f"Started sprint {sprint_id}")
                return True
        return False
    
    def complete_sprint(self, sprint_id: str, completed_items: List[str]) -> Dict[str, Any]:
        """
        Complete a sprint and calculate metrics
        """
        if sprint_id not in self.sprints:
            return {}
        
        sprint = self.sprints[sprint_id]
        sprint['status'] = SprintStatus.COMPLETED.value
        sprint['actual_end_date'] = datetime.now().isoformat()
        
        # Calculate completion metrics
        total_items = len(sprint['committed_items'])
        completed_count = len(completed_items)
        carried_over = total_items - completed_count
        
        completed_effort = sum(
            item['effort'] for item in sprint['committed_items']
            if item['id'] in completed_items
        )
        
        sprint['metrics'].update({
            'items_completed': completed_count,
            'items_carried_over': carried_over,
            'actual_velocity': completed_effort,
            'completion_rate': completed_count / max(total_items, 1),
            'velocity_accuracy': completed_effort / max(sprint['metrics']['planned_velocity'], 1)
        })
        
        self.logger.info(f"Completed sprint {sprint_id}: {completed_count}/{total_items} items")
        return sprint['metrics']
    
    def get_sprint_burndown_data(self, sprint_id: str) -> Dict[str, Any]:
        """
        Get data for Sprint Burndown chart
        """
        if sprint_id not in self.sprints:
            return {}
        
        sprint = self.sprints[sprint_id]
        total_effort = sprint['metrics']['planned_velocity']
        duration_hours = sprint['duration_hours']
        
        # Generate ideal burndown line
        ideal_line = []
        for hour in range(duration_hours + 1):
            remaining = total_effort - (total_effort * hour / duration_hours)
            ideal_line.append({
                'hour': hour,
                'remaining_effort': max(0, remaining)
            })
        
        return {
            'sprint_id': sprint_id,
            'total_effort': total_effort,
            'duration_hours': duration_hours,
            'ideal_burndown': ideal_line,
            'actual_burndown': []  # Would be populated with real-time data
        }
    
    def get_sprint_summary(self, sprint_id: str) -> Dict[str, Any]:
        """Get comprehensive sprint summary"""
        if sprint_id not in self.sprints:
            return {}
        
        sprint = self.sprints[sprint_id]
        return {
            'sprint_id': sprint_id,
            'sprint_goal': sprint['sprint_goal'],
            'status': sprint['status'],
            'duration_hours': sprint['duration_hours'],
            'team_capacity': sprint['team_capacity'],
            'committed_items_count': len(sprint['committed_items']),
            'total_committed_effort': sprint['total_committed_effort'],
            'capacity_utilization': sprint['total_committed_effort'] / max(sprint['available_capacity'], 1),
            'metrics': sprint['metrics']
        }
    
    def get_all_sprints(self) -> List[Dict[str, Any]]:
        """Get summary of all sprints"""
        return [self.get_sprint_summary(sprint_id) for sprint_id in self.sprints.keys()]

if __name__ == "__main__":
    # Example usage
    planner = SprintPlanner(default_sprint_duration_hours=12)
    
    # Sample product backlog
    sample_backlog = [
        {
            'id': 'PBI-001',
            'description': 'User authentication system',
            'effort': 8,
            'priority_score': 10,
            'status': 'ready'
        },
        {
            'id': 'PBI-002',
            'description': 'Dashboard analytics',
            'effort': 5,
            'priority_score': 8,
            'status': 'ready'
        },
        {
            'id': 'PBI-003',
            'description': 'User profile management',
            'effort': 3,
            'priority_score': 6,
            'status': 'ready'
        }
    ]
    
    # Create sprint backlog
    sprint = planner.create_sprint_backlog(sample_backlog, team_capacity=3)
    print(f"Created sprint: {sprint['sprint_id']}")
    print(f"Sprint goal: {sprint['sprint_goal']}")
    print(f"Committed items: {len(sprint['committed_items'])}")
