#!/usr/bin/env python3
"""
Smoke Test for Step 7: Impediment Resolution Logic
Focused test to verify core impediment functionality
"""

import sys
import os
from datetime import datetime

# Add zeus_core to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'zeus_core'))

try:
    from impediment_resolution import ImpedimentResolver, Impediment, ROAMStatus, ImpedimentStatus
    print("✅ Successfully imported impediment resolution modules")
except ImportError as e:
    print(f"❌ Failed to import modules: {e}")
    sys.exit(1)

def test_impediment_logging():
    """Test basic impediment logging"""
    print("\n=== Testing Impediment Logging ===")
    
    resolver = ImpedimentResolver()
    
    # Test different types of impediments
    test_cases = [
        ("agent_001", "System crash due to memory error"),
        ("agent_002", "API timeout from external service"),
        ("agent_003", "Queue overload - need more capacity"),
        ("agent_004", "Workflow approval blocked"),
        ("agent_005", "Third-party vendor integration failure")
    ]
    
    for agent_id, description in test_cases:
        impediment = resolver.log_impediment(agent_id, description)
        print(f"✅ Logged impediment {impediment.id[:8]}... for {agent_id}")
        print(f"   Type: {impediment.impediment_type.value}")
        print(f"   ROAM: {impediment.roam.value}")
        print(f"   Status: {impediment.status.value}")
    
    return len(resolver.impediments) == len(test_cases)

def test_roam_classification():
    """Test ROAM classification logic"""
    print("\n=== Testing ROAM Classification ===")
    
    resolver = ImpedimentResolver()
    
    # Test specific ROAM classifications
    test_cases = [
        ("System needs restart", ROAMStatus.OWNED),
        ("External vendor delay", ROAMStatus.ACCEPTED),
        ("Process approval required", ROAMStatus.MITIGATED),
        ("Queue capacity issue", ROAMStatus.OWNED)
    ]
    
    passed = 0
    for description, expected_roam in test_cases:
        impediment = resolver.log_impediment("test_agent", description)
        if impediment.roam == expected_roam:
            print(f"✅ Correct ROAM classification: {description} -> {expected_roam.value}")
            passed += 1
        else:
            print(f"❌ Wrong ROAM classification: {description} -> {impediment.roam.value} (expected {expected_roam.value})")
    
    return passed == len(test_cases)

def test_auto_resolution():
    """Test auto-resolution mechanisms"""
    print("\n=== Testing Auto-Resolution ===")
    
    resolver = ImpedimentResolver()
    
    # Test auto-resolvable impediments
    auto_resolve_cases = [
        "System crash - needs restart",
        "Network timeout error",
        "Queue overload situation",
        "Capacity limit reached"
    ]
    
    auto_resolved_count = 0
    for description in auto_resolve_cases:
        impediment = resolver.log_impediment("auto_test_agent", description)
        if impediment.status == ImpedimentStatus.CLOSED:
            print(f"✅ Auto-resolved: {description}")
            print(f"   Action: {impediment.resolution_action}")
            auto_resolved_count += 1
        else:
            print(f"⚠️  Not auto-resolved: {description}")
    
    print(f"Auto-resolved {auto_resolved_count}/{len(auto_resolve_cases)} impediments")
    return auto_resolved_count > 0

def test_escalation():
    """Test impediment escalation"""
    print("\n=== Testing Escalation ===")
    
    resolver = ImpedimentResolver()
    
    # Create an impediment that won't auto-resolve
    impediment = resolver.log_impediment("escalation_agent", "Complex integration issue")
    impediment_id = impediment.id
    
    # Test escalation
    success = resolver.escalate_impediment(impediment_id)
    
    if success and resolver.impediments[impediment_id].escalated:
        print(f"✅ Successfully escalated impediment {impediment_id[:8]}...")
        return True
    else:
        print(f"❌ Failed to escalate impediment {impediment_id[:8]}...")
        return False

def test_statistics():
    """Test impediment statistics"""
    print("\n=== Testing Statistics ===")
    
    resolver = ImpedimentResolver()
    
    # Create mix of impediments
    resolver.log_impediment("stats_agent_1", "System crash")  # Should auto-resolve
    resolver.log_impediment("stats_agent_2", "Manual process issue")  # Won't auto-resolve
    resolver.log_impediment("stats_agent_3", "Network timeout")  # Should auto-resolve
    
    stats = resolver.get_impediment_stats()
    
    print(f"✅ Total impediments: {stats['total']}")
    print(f"✅ Resolved: {stats['resolved']}")
    print(f"✅ Auto-resolved: {stats['auto_resolved']}")
    print(f"✅ Resolution rate: {stats['resolution_rate']:.2%}")
    print(f"✅ Auto-resolution rate: {stats['auto_resolution_rate']:.2%}")
    
    return stats['total'] > 0

def test_api_simulation():
    """Simulate API endpoint behavior"""
    print("\n=== Testing API Simulation ===")
    
    # Simulate POST /impediments {agent_id, type, detail}
    api_requests = [
        {"agent_id": "api_agent_001", "type": "technical", "detail": "Database connection timeout"},
        {"agent_id": "api_agent_002", "type": "resource", "detail": "CPU usage at 100%"},
        {"agent_id": "api_agent_003", "type": "dependency", "detail": "Waiting for upstream service"}
    ]
    
    resolver = ImpedimentResolver()
    
    for request in api_requests:
        # Simulate API call
        impediment = resolver.log_impediment(request["agent_id"], request["detail"])
        
        # Verify response structure matches expected API response
        response = {
            "id": impediment.id,
            "timestamp": impediment.timestamp.isoformat(),
            "agent": impediment.agent,
            "description": impediment.description,
            "roam": impediment.roam.value,
            "status": impediment.status.value,
            "type": impediment.impediment_type.value
        }
        
        print(f"✅ API Response for {request['agent_id']}: {response['status']}")
    
    return len(resolver.impediments) == len(api_requests)

def main():
    """Run all smoke tests"""
    print("Zeus SAFe Step 7: Impediment Resolution Logic - Smoke Test")
    print("=" * 60)
    
    tests = [
        ("Impediment Logging", test_impediment_logging),
        ("ROAM Classification", test_roam_classification),
        ("Auto-Resolution", test_auto_resolution),
        ("Escalation", test_escalation),
        ("Statistics", test_statistics),
        ("API Simulation", test_api_simulation)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            if test_func():
                print(f"\n✅ {test_name}: PASSED")
                passed += 1
            else:
                print(f"\n❌ {test_name}: FAILED")
                failed += 1
        except Exception as e:
            print(f"\n❌ {test_name}: ERROR - {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"Smoke Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("\n🎉 ALL SMOKE TESTS PASSED! Step 7 implementation is working correctly.")
        return True
    else:
        print(f"\n❌ {failed} tests failed. Please review implementation.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)