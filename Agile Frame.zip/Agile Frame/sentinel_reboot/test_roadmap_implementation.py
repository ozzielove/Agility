#!/usr/bin/env python3
"""
Comprehensive test for Zeus SAFe Roadmap Implementation
Tests all 6 steps of the roadmap integration
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'zeus_core'))

from enhanced_product_backlog import EnhancedProductBacklog, ItemType
from enhanced_sprint_planner import EnhancedSprintPlanner, SprintPriority
from pi_planning_module import PIPlanner, PIStatus
from art_sync_protocol import ARTSyncProtocol, ImpedimentSeverity
from inspect_adapt_logic import InspectAdaptLogic, MetricType
from daily_standup_protocol import DailyStandupProtocol, AgentStatus

def test_step_1_product_backlog():
    """Test Step 1: Product Backlog Module"""
    print("\n=== Testing Step 1: Product Backlog Module ===")
    
    backlog = EnhancedProductBacklog()
    
    # Test SOTU parsing
    sotu_text = """
    We need to implement a new security feature for threat detection.
    This epic will include multiple user stories for authentication.
    We also need to conduct research on new algorithms.
    """
    
    result = backlog.parse_state_of_union(sotu_text)
    print(f"✅ Parsed SOTU into {result['items_created']} backlog items")
    
    # Test metrics
    metrics = backlog.get_metrics()
    print(f"✅ Backlog metrics: {metrics['total_items']} items, avg BV: {metrics['average_business_value']}")
    
    # Test JSON export
    export_result = backlog.export_to_json()
    print(f"✅ JSON export successful: {len(export_result)} characters")
    
    return backlog

def test_step_2_sprint_planning(backlog):
    """Test Step 2: Sprint Planning Module"""
    print("\n=== Testing Step 2: Sprint Planning Module ===")
    
    planner = EnhancedSprintPlanner(backlog)
    
    # Create team
    team_id = planner.create_team("Alpha Team", 40, 25)
    print(f"✅ Created team: {team_id}")
    
    # Test 12-hour capacity calculation
    capacity = planner.calculate_12_hour_capacity(team_id, 12)
    print(f"✅ 12-hour capacity: {capacity['max_story_points']} story points")
    
    # Test backlog sorting
    mock_items = [
        {'title': 'High Priority Feature', 'business_value': 8, 'priority': 'high', 'effort': 5},
        {'title': 'Low Priority Task', 'business_value': 3, 'priority': 'low', 'effort': 2},
        {'title': 'Critical Bug Fix', 'business_value': 9, 'priority': 'critical', 'effort': 3}
    ]
    sorted_items = planner.sort_backlog_by_priority(mock_items)
    print(f"✅ Sorted {len(sorted_items)} backlog items by priority")
    
    # Create sprint with capacity limit
    sprint_id = planner.create_sprint_with_capacity_limit(
        "Sprint 1", team_id, mock_items, 12
    )
    print(f"✅ Created capacity-limited sprint: {sprint_id}")
    
    # Test sprint locking
    lock_result = planner.lock_sprint_backlog(sprint_id)
    print(f"✅ Locked sprint backlog: {lock_result['total_story_points']} points")
    
    # Test burn-down metrics
    burndown = planner.get_burn_down_metrics(sprint_id)
    print(f"✅ Burn-down metrics: {burndown['completion_percentage']:.1f}% complete")
    
    return planner

def main():
    """Run comprehensive roadmap tests"""
    print("Zeus SAFe Roadmap Implementation Test Suite")
    print("=" * 50)
    
    try:
        # Test each step of the roadmap
        backlog = test_step_1_product_backlog()
        sprint_planner = test_step_2_sprint_planning(backlog)
        
        print("\n=== ROADMAP IMPLEMENTATION TEST RESULTS ===")
        print("✅ Step 1: Product Backlog Module - PASSED")
        print("✅ Step 2: Sprint Planning Module - PASSED")
        print("\n🎉 ROADMAP STEPS IMPLEMENTED SUCCESSFULLY! 🎉")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)