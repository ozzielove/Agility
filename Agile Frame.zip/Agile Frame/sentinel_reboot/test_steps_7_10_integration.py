#!/usr/bin/env python3
"""
Integration test for Zeus SAFe Steps 7-10
Test impediment resolution, burndown charts, sprint review, and retrospectives
"""

from datetime import datetime, timedelta
import sys
import os

# Add zeus_core to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'zeus_core'))

from impediment_resolution import ImpedimentResolver, Impediment, ROAMStatus, ImpedimentStatus
from burndown_generator import BurndownGenerator, SprintBurndownConfig
from sprint_review import SprintReviewGenerator, CompletedItem, SprintMetrics
from sprint_retrospective import SprintRetrospectiveAnalyzer, RetrospectiveData, CycleTimeData


def test_impediment_resolution():
    """Test Step 7: Impediment Resolution Logic"""
    print("\n=== Testing Step 7: Impediment Resolution ===")
    
    resolver = ImpedimentResolver()
    
    # Test impediment logging and classification
    impediment1 = resolver.log_impediment("agent_001", "System crash due to memory error")
    impediment2 = resolver.log_impediment("agent_002", "API timeout from external service")
    impediment3 = resolver.log_impediment("agent_003", "Queue overload - need more capacity")
    
    print(f"✅ Logged {len(resolver.impediments)} impediments")
    
    # Test auto-resolution
    auto_resolved = sum(1 for imp in resolver.impediments.values() 
                       if imp.status == ImpedimentStatus.CLOSED)
    print(f"✅ Auto-resolved {auto_resolved} impediments")
    
    # Test escalation
    for imp_id in list(resolver.impediments.keys())[:1]:
        resolver.escalate_impediment(imp_id)
    
    # Test statistics
    stats = resolver.get_impediment_stats()
    print(f"✅ Impediment stats: {stats}")
    
    return True


def test_burndown_generator():
    """Test Step 8: Sprint Burndown Chart Generator"""
    print("\n=== Testing Step 8: Burndown Chart Generator ===")
    
    generator = BurndownGenerator()
    
    # Create sprint configuration
    start_time = datetime.now()
    end_time = start_time + timedelta(days=14)
    
    config = SprintBurndownConfig(
        sprint_id="SPRINT_001",
        total_points=100.0,
        start_time=start_time,
        end_time=end_time
    )
    
    # Initialize sprint
    generator.initialize_sprint(config)
    print(f"✅ Initialized sprint {config.sprint_id}")
    
    # Simulate progress updates
    for day in range(5):
        completed_points = day * 15 + 10
        update_time = start_time + timedelta(days=day, hours=10)
        generator.update_burndown(config.sprint_id, completed_points, update_time)
    
    print(f"✅ Updated burndown with 5 data points")
    
    # Generate chart and reports
    chart_path = generator.save_chart(config.sprint_id)
    csv_path = generator.save_csv_data(config.sprint_id)
    html_path = generator.save_html_report(config.sprint_id)
    
    print(f"✅ Generated chart: {chart_path}")
    print(f"✅ Generated CSV: {csv_path}")
    print(f"✅ Generated HTML: {html_path}")
    
    # Test metrics
    metrics = generator.get_sprint_metrics(config.sprint_id)
    print(f"✅ Sprint metrics: {metrics['progress_percentage']:.1f}% complete")
    
    return True


def test_sprint_review():
    """Test Step 9: Sprint Review & System Demo Protocol"""
    print("\n=== Testing Step 9: Sprint Review & Demo Protocol ===")
    
    review_generator = SprintReviewGenerator()
    
    # Register completed items
    items = [
        CompletedItem(
            id="ITEM_001",
            title="User Authentication Feature",
            business_value=85.0,
            story_points=8.0,
            completion_date=datetime.now(),
            demo_artifacts=["auth_demo.mp4", "test_results.html"]
        ),
        CompletedItem(
            id="ITEM_002",
            title="Performance Optimization",
            business_value=70.0,
            story_points=5.0,
            completion_date=datetime.now(),
            demo_artifacts=["perf_report.pdf"]
        ),
        CompletedItem(
            id="ITEM_003",
            title="Bug Fixes",
            business_value=60.0,
            story_points=3.0,
            completion_date=datetime.now()
        )
    ]
    
    sprint_id = "SPRINT_001"
    for item in items:
        review_generator.register_completed_item(sprint_id, item)
    
    print(f"✅ Registered {len(items)} completed items")
    
    # Execute sprint review protocol
    result = review_generator.execute_sprint_review_protocol(
        sprint_id=sprint_id,
        planned_points=20.0,
        team_capacity_hours=320.0,
        stakeholder_emails=["pm@company.com", "stakeholder@company.com"],
        defects_found=2,
        scope_changes=1
    )
    
    print(f"✅ Sprint review protocol: {result['status']}")
    print(f"✅ Generated PDF: {result['pdf_path']}")
    print(f"✅ Sent {result['notifications_sent']} notifications")
    
    # Test sprint summary
    summary = review_generator.get_sprint_summary(sprint_id)
    print(f"✅ Sprint summary: {summary['total_business_value']} BV delivered")
    
    return True


def test_sprint_retrospective():
    """Test Step 10: Sprint Retrospective Module"""
    print("\n=== Testing Step 10: Sprint Retrospective Analysis ===")
    
    analyzer = SprintRetrospectiveAnalyzer()
    
    # Create mock cycle time data
    cycle_times = [
        CycleTimeData(
            item_id="ITEM_001",
            start_time=datetime.now() - timedelta(days=5),
            end_time=datetime.now() - timedelta(days=1),
            stage_times={
                "development": 24.0,
                "testing": 16.0,
                "review": 8.0,
                "deployment": 4.0
            },
            total_cycle_time=52.0
        ),
        CycleTimeData(
            item_id="ITEM_002",
            start_time=datetime.now() - timedelta(days=4),
            end_time=datetime.now(),
            stage_times={
                "development": 20.0,
                "testing": 24.0,  # Bottleneck
                "review": 6.0,
                "deployment": 2.0
            },
            total_cycle_time=52.0
        )
    ]
    
    # Create retrospective data
    retrospective_data = RetrospectiveData(
        sprint_id="SPRINT_001",
        burndown_data=[],
        impediments=[
            {"type": "technical", "created_at": datetime.now().isoformat(), "resolved_at": datetime.now().isoformat()},
            {"type": "resource", "created_at": datetime.now().isoformat(), "resolved_at": None}
        ],
        cycle_times=cycle_times,
        throughput_data={"completed_points": 16.0, "committed_points": 20.0},
        team_feedback=["Need better testing automation", "Communication could be improved"]
    )
    
    # Execute retrospective workflow
    result = analyzer.execute_retrospective_workflow(retrospective_data)
    
    print(f"✅ Retrospective workflow: {result['status']}")
    print(f"✅ Generated report: {result['retrospective_report_md']}")
    print(f"✅ Generated backlog: {result['improvement_backlog_json']}")
    
    # Test improvement summary
    summary = analyzer.get_improvement_summary("SPRINT_001")
    print(f"✅ Generated {summary['total_improvements']} improvements")
    print(f"✅ High priority items: {summary['priority_breakdown']['high']}")
    
    return True


def test_integration():
    """Test integration between all modules"""
    print("\n=== Testing Integration Between All Modules ===")
    
    # Test data flow from impediments to retrospective
    resolver = ImpedimentResolver()
    analyzer = SprintRetrospectiveAnalyzer()
    
    # Create impediments
    resolver.log_impediment("agent_001", "Testing bottleneck - slow test execution")
    resolver.log_impediment("agent_002", "Code review delays")
    
    # Export impediments for retrospective
    impediment_data = []
    for imp in resolver.impediments.values():
        impediment_data.append({
            "type": imp.impediment_type.value,
            "created_at": imp.timestamp.isoformat(),
            "resolved_at": datetime.now().isoformat() if imp.status == ImpedimentStatus.CLOSED else None
        })
    
    print(f"✅ Exported {len(impediment_data)} impediments for retrospective")
    
    # Test burndown data integration
    generator = BurndownGenerator()
    config = SprintBurndownConfig(
        sprint_id="INTEGRATION_SPRINT",
        total_points=50.0,
        start_time=datetime.now() - timedelta(days=7),
        end_time=datetime.now() + timedelta(days=7)
    )
    generator.initialize_sprint(config)
    
    # Export burndown data
    burndown_export = generator.export_sprint_data(config.sprint_id)
    print(f"✅ Exported burndown data for integration")
    
    # Test sprint review to retrospective flow
    review_generator = SprintReviewGenerator()
    completed_item = CompletedItem(
        id="INTEGRATION_ITEM",
        title="Integration Test Feature",
        business_value=90.0,
        story_points=13.0,
        completion_date=datetime.now()
    )
    review_generator.register_completed_item(config.sprint_id, completed_item)
    
    # Generate metrics for retrospective
    metrics = review_generator.calculate_sprint_metrics(
        config.sprint_id, 50.0, 320.0, 1, 0, 5
    )
    
    print(f"✅ Generated sprint metrics for retrospective: {metrics.velocity} points")
    
    print("\n🎉 All integration tests passed!")
    return True


def main():
    """Run all tests for Steps 7-10"""
    print("Zeus SAFe Steps 7-10 Integration Test Suite")
    print("=" * 50)
    
    tests = [
        test_impediment_resolution,
        test_burndown_generator,
        test_sprint_review,
        test_sprint_retrospective,
        test_integration
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
                print(f"✅ {test.__name__} PASSED")
            else:
                failed += 1
                print(f"❌ {test.__name__} FAILED")
        except Exception as e:
            failed += 1
            print(f"❌ {test.__name__} FAILED: {e}")
    
    print("\n" + "=" * 50)
    print(f"Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("\n🎉 ALL TESTS PASSED! Steps 7-10 implementation complete.")
        return True
    else:
        print(f"\n❌ {failed} tests failed. Please review implementation.")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)