#!/usr/bin/env python3
"""
Copy all quantum agents from affiliate-engine-autonomy to sentinel_reboot
"""

import shutil
import os
from pathlib import Path

source_dir = Path("/Users/ozirusmorency/Desktop/affiliate-engine-autonomy 2/agent/agents/Active Agents/Final_Patched_Agents_Complete")
target_dir = Path("/Users/ozirusmorency/sentinel_reboot/agents")

# Ensure target directory exists
target_dir.mkdir(exist_ok=True)

# Copy all JSON files
copied_files = []
for json_file in source_dir.glob("*.json"):
    target_file = target_dir / json_file.name
    shutil.copy2(json_file, target_file)
    copied_files.append(json_file.name)
    print(f"Copied: {json_file.name}")

print(f"\nTotal files copied: {len(copied_files)}")
print("Files copied:")
for file in sorted(copied_files):
    print(f"  - {file}")
