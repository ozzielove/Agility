#!/usr/bin/env python3
"""
n8n JSON Schema Validation Script
Validates n8n workflow files against official schema patterns
"""

import json
import os
import sys
from pathlib import Path

def validate_n8n_workflow(file_path):
    """Validate a single n8n workflow file"""
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Check for n8n workflow structure
        required_fields = ['nodes', 'connections']
        optional_fields = ['name', 'active', 'createdAt', 'updatedAt', 'id']
        
        # Basic structure validation
        if not isinstance(data, dict):
            return False, "Root must be an object"
            
        # Check for workflow indicators
        has_nodes = 'nodes' in data
        has_connections = 'connections' in data
        has_workflow_meta = any(field in data for field in ['name', 'active', 'id'])
        
        if has_nodes and isinstance(data['nodes'], list):
            # Validate node structure
            for i, node in enumerate(data['nodes']):
                if not isinstance(node, dict):
                    return False, f"Node {i} must be an object"
                if 'type' not in node:
                    return False, f"Node {i} missing required 'type' field"
                if 'position' not in node:
                    return False, f"Node {i} missing required 'position' field"
        
        if has_connections and isinstance(data['connections'], dict):
            # Basic connections validation
            for node_name, connections in data['connections'].items():
                if not isinstance(connections, dict):
                    return False, f"Connections for {node_name} must be an object"
        
        # Determine if this is likely an n8n workflow
        is_n8n_workflow = has_nodes and (has_connections or has_workflow_meta)
        
        return True, "Valid n8n workflow structure" if is_n8n_workflow else "Not an n8n workflow file"
        
    except json.JSONDecodeError as e:
        return False, f"Invalid JSON: {e}"
    except Exception as e:
        return False, f"Validation error: {e}"

def main():
    """Main validation function"""
    assets_dir = Path('assets')
    if not assets_dir.exists():
        print("❌ Assets directory not found")
        return 1
    
    json_files = list(assets_dir.glob('*.json'))
    if not json_files:
        print("⚠️  No JSON files found in assets directory")
        return 0
    
    print(f"🔍 Found {len(json_files)} JSON files to validate")
    
    n8n_workflows = []
    validation_errors = []
    
    for json_file in json_files:
        is_valid, message = validate_n8n_workflow(json_file)
        
        if not is_valid:
            validation_errors.append(f"{json_file.name}: {message}")
            print(f"❌ {json_file.name}: {message}")
        elif "n8n workflow" in message:
            n8n_workflows.append(json_file.name)
            print(f"✅ {json_file.name}: {message}")
        else:
            print(f"ℹ️  {json_file.name}: {message}")
    
    print(f"\n📊 Validation Summary:")
    print(f"   • Total JSON files: {len(json_files)}")
    print(f"   • n8n workflows found: {len(n8n_workflows)}")
    print(f"   • Validation errors: {len(validation_errors)}")
    
    if validation_errors:
        print(f"\n❌ VALIDATION FAILED - {len(validation_errors)} errors found")
        return 1
    else:
        print(f"\n✅ VALIDATION PASSED - All files valid")
        return 0

if __name__ == '__main__':
    sys.exit(main())