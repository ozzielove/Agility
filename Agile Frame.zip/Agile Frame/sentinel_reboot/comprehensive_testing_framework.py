#!/usr/bin/env python3
"""
Comprehensive Testing Framework for Consolidated Agent Swarm
Includes: Functional, Unit, Integration, Regression, Smoke, Performance, Load, and Stress Testing
"""

import json
import time
import asyncio
import concurrent.futures
import psutil
import requests
import logging
from pathlib import Path
from typing import Dict, List, Any, Tuple
from datetime import datetime
import subprocess
import threading
import statistics

class ComprehensiveTestingFramework:
    def __init__(self, agents_dir: str = "./agents"):
        self.agents_dir = Path(agents_dir)
        self.test_results = {
            "functional": {},
            "unit": {},
            "integration": {},
            "regression": {},
            "smoke": {},
            "performance": {},
            "load": {},
            "stress": {}
        }
        self.setup_logging()
        self.agents = self.load_all_agents()
        
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('comprehensive_testing.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def load_all_agents(self) -> Dict[str, Any]:
        """Load all agent configurations"""
        agents = {}
        for json_file in self.agents_dir.glob("*.json"):
            try:
                with open(json_file, 'r') as f:
                    agent_data = json.load(f)
                    agent_name = json_file.stem
                    agents[agent_name] = agent_data
                    self.logger.info(f"Loaded agent: {agent_name}")
            except Exception as e:
                self.logger.error(f"Failed to load {json_file}: {e}")
        return agents
        
    # FUNCTIONAL TESTING
    def test_functional_agent_initialization(self) -> Dict[str, bool]:
        """Test if all agents can be initialized properly"""
        results = {}
        for agent_name, agent_data in self.agents.items():
            try:
                # Check required fields
                required_fields = ['agent_id', 'name', 'type', 'status', 'capabilities']
                has_required = all(field in agent_data for field in required_fields)
                
                # Check status is active
                is_active = agent_data.get('status') == 'active'
                
                # Check capabilities exist
                has_capabilities = len(agent_data.get('capabilities', [])) > 0
                
                results[agent_name] = has_required and is_active and has_capabilities
                
            except Exception as e:
                self.logger.error(f"Functional test failed for {agent_name}: {e}")
                results[agent_name] = False
                
        return results
        
    def test_functional_agent_communication(self) -> Dict[str, bool]:
        """Test agent communication protocols"""
        results = {}
        for agent_name, agent_data in self.agents.items():
            try:
                # Check communication configuration
                comm_config = agent_data.get('communication', {})
                has_input_channels = len(comm_config.get('input_channels', [])) > 0
                has_output_channels = len(comm_config.get('output_channels', [])) > 0
                has_protocols = len(comm_config.get('protocols', [])) > 0
                
                results[agent_name] = has_input_channels and has_output_channels and has_protocols
                
            except Exception as e:
                self.logger.error(f"Communication test failed for {agent_name}: {e}")
                results[agent_name] = False
                
        return results
        
    # UNIT TESTING
    def test_unit_agent_modules(self) -> Dict[str, Dict[str, bool]]:
        """Test individual agent modules"""
        results = {}
        for agent_name, agent_data in self.agents.items():
            agent_results = {}
            try:
                modules = agent_data.get('modules', {})
                for module_name, module_config in modules.items():
                    # Test if module is properly configured
                    is_enabled = module_config.get('enabled', False)
                    has_config = len(module_config) > 1  # More than just 'enabled'
                    agent_results[module_name] = is_enabled and has_config
                    
                results[agent_name] = agent_results
                
            except Exception as e:
                self.logger.error(f"Unit test failed for {agent_name}: {e}")
                results[agent_name] = {'error': False}
                
        return results
        
    def test_unit_configuration_validation(self) -> Dict[str, bool]:
        """Test agent configuration validation"""
        results = {}
        for agent_name, agent_data in self.agents.items():
            try:
                config = agent_data.get('configuration', {})
                
                # Check for valid configuration values
                valid_config = True
                for key, value in config.items():
                    if isinstance(value, (int, float)) and value < 0:
                        valid_config = False
                    if isinstance(value, str) and not value.strip():
                        valid_config = False
                        
                results[agent_name] = valid_config
                
            except Exception as e:
                self.logger.error(f"Configuration validation failed for {agent_name}: {e}")
                results[agent_name] = False
                
        return results
        
    # INTEGRATION TESTING
    def test_integration_agent_dependencies(self) -> Dict[str, bool]:
        """Test agent dependency resolution"""
        results = {}
        all_agent_names = set(self.agents.keys())
        
        for agent_name, agent_data in self.agents.items():
            try:
                dependencies = agent_data.get('dependencies', [])
                
                # Check if all dependencies exist
                deps_satisfied = True
                for dep in dependencies:
                    # Check if dependency exists in agent pool or is external service
                    if dep not in all_agent_names and not self._is_external_service(dep):
                        deps_satisfied = False
                        break
                        
                results[agent_name] = deps_satisfied
                
            except Exception as e:
                self.logger.error(f"Dependency test failed for {agent_name}: {e}")
                results[agent_name] = False
                
        return results
        
    def test_integration_service_connectivity(self) -> Dict[str, bool]:
        """Test connectivity to external services"""
        results = {}
        services_to_test = {
            'redis': 'http://localhost:6379',
            'postgres': 'postgresql://localhost:5432',
            'n8n': 'http://localhost:5678',
            'qdrant': 'http://localhost:6333'
        }
        
        for service_name, endpoint in services_to_test.items():
            try:
                if service_name == 'n8n':
                    response = requests.get(endpoint, timeout=5)
                    results[service_name] = response.status_code == 200
                elif service_name == 'qdrant':
                    response = requests.get(f"{endpoint}/collections", timeout=5)
                    results[service_name] = response.status_code in [200, 404]  # 404 is ok for empty collections
                else:
                    # For redis and postgres, just check if port is open
                    import socket
                    host, port = endpoint.split('//')[-1].split(':')[0], int(endpoint.split(':')[-1])
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(5)
                    result = sock.connect_ex((host, port))
                    results[service_name] = result == 0
                    sock.close()
                    
            except Exception as e:
                self.logger.error(f"Service connectivity test failed for {service_name}: {e}")
                results[service_name] = False
                
        return results
        
    # REGRESSION TESTING
    def test_regression_agent_compatibility(self) -> Dict[str, bool]:
        """Test backward compatibility of agent configurations"""
        results = {}
        for agent_name, agent_data in self.agents.items():
            try:
                # Check for required legacy fields
                legacy_fields = ['agent_id', 'name', 'type', 'capabilities']
                has_legacy = all(field in agent_data for field in legacy_fields)
                
                # Check version compatibility
                version = agent_data.get('version', '')
                is_compatible = 'SENTINEL' in version or 'v2' in version
                
                results[agent_name] = has_legacy and is_compatible
                
            except Exception as e:
                self.logger.error(f"Regression test failed for {agent_name}: {e}")
                results[agent_name] = False
                
        return results
        
    # SMOKE TESTING
    def test_smoke_critical_agents(self) -> Dict[str, bool]:
        """Test critical agents are operational"""
        critical_agents = ['zeus_unified', 'aletheia', 'chronos', 'hermes']
        results = {}
        
        for agent_name in critical_agents:
            # Find agent by partial name match
            matching_agents = [name for name in self.agents.keys() if any(crit in name.lower() for crit in [agent_name])]
            
            if matching_agents:
                agent_data = self.agents[matching_agents[0]]
                is_critical = agent_data.get('priority') == 'critical'
                is_active = agent_data.get('status') == 'active'
                results[agent_name] = is_critical and is_active
            else:
                results[agent_name] = False
                
        return results
        
    # PERFORMANCE TESTING
    def test_performance_agent_loading(self) -> Dict[str, float]:
        """Test agent loading performance"""
        results = {}
        
        for agent_name in self.agents.keys():
            start_time = time.time()
            
            # Simulate agent loading
            try:
                agent_file = self.agents_dir / f"{agent_name}.json"
                with open(agent_file, 'r') as f:
                    json.load(f)
                    
                load_time = time.time() - start_time
                results[agent_name] = load_time
                
            except Exception as e:
                self.logger.error(f"Performance test failed for {agent_name}: {e}")
                results[agent_name] = float('inf')
                
        return results
        
    def test_performance_memory_usage(self) -> Dict[str, float]:
        """Test memory usage of agent operations"""
        results = {}
        process = psutil.Process()
        
        for agent_name, agent_data in self.agents.items():
            try:
                initial_memory = process.memory_info().rss / 1024 / 1024  # MB
                
                # Simulate agent operations
                _ = json.dumps(agent_data)
                _ = agent_data.get('capabilities', [])
                _ = agent_data.get('configuration', {})
                
                final_memory = process.memory_info().rss / 1024 / 1024  # MB
                memory_delta = final_memory - initial_memory
                
                results[agent_name] = memory_delta
                
            except Exception as e:
                self.logger.error(f"Memory test failed for {agent_name}: {e}")
                results[agent_name] = float('inf')
                
        return results
        
    # LOAD TESTING
    def test_load_concurrent_agent_access(self, num_threads: int = 10) -> Dict[str, List[float]]:
        """Test concurrent access to agents"""
        results = {}
        
        def access_agent(agent_name: str) -> float:
            start_time = time.time()
            try:
                agent_data = self.agents[agent_name]
                _ = agent_data.get('capabilities')
                _ = json.dumps(agent_data)
                return time.time() - start_time
            except Exception:
                return float('inf')
                
        for agent_name in list(self.agents.keys())[:5]:  # Test first 5 agents
            with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [executor.submit(access_agent, agent_name) for _ in range(num_threads)]
                times = [future.result() for future in concurrent.futures.as_completed(futures)]
                results[agent_name] = times
                
        return results
        
    # STRESS TESTING
    def test_stress_maximum_load(self, duration_seconds: int = 30) -> Dict[str, Any]:
        """Test system under maximum load"""
        results = {
            'start_time': datetime.now().isoformat(),
            'duration': duration_seconds,
            'operations_completed': 0,
            'errors': 0,
            'avg_response_time': 0.0,
            'max_memory_usage': 0.0
        }
        
        start_time = time.time()
        operations = 0
        errors = 0
        response_times = []
        max_memory = 0.0
        
        process = psutil.Process()
        
        while time.time() - start_time < duration_seconds:
            try:
                op_start = time.time()
                
                # Perform intensive operations
                for agent_name, agent_data in self.agents.items():
                    _ = json.dumps(agent_data)
                    _ = agent_data.get('capabilities', [])
                    
                op_time = time.time() - op_start
                response_times.append(op_time)
                operations += 1
                
                # Monitor memory
                current_memory = process.memory_info().rss / 1024 / 1024  # MB
                max_memory = max(max_memory, current_memory)
                
            except Exception as e:
                errors += 1
                self.logger.error(f"Stress test error: {e}")
                
        results['operations_completed'] = operations
        results['errors'] = errors
        results['avg_response_time'] = statistics.mean(response_times) if response_times else 0.0
        results['max_memory_usage'] = max_memory
        
        return results
        
    def _is_external_service(self, service_name: str) -> bool:
        """Check if a service is external (not an agent)"""
        external_services = ['redis', 'postgres', 'n8n', 'qdrant', 'zeus_protocol', 'sentinel_framework', 'chronos_agent']
        return any(ext in service_name.lower() for ext in external_services)
        
    def run_all_tests(self) -> Dict[str, Any]:
        """Execute all testing phases"""
        self.logger.info("Starting comprehensive testing framework...")
        
        # Functional Testing
        self.logger.info("Running Functional Tests...")
        self.test_results['functional']['agent_initialization'] = self.test_functional_agent_initialization()
        self.test_results['functional']['agent_communication'] = self.test_functional_agent_communication()
        
        # Unit Testing
        self.logger.info("Running Unit Tests...")
        self.test_results['unit']['agent_modules'] = self.test_unit_agent_modules()
        self.test_results['unit']['configuration_validation'] = self.test_unit_configuration_validation()
        
        # Integration Testing
        self.logger.info("Running Integration Tests...")
        self.test_results['integration']['agent_dependencies'] = self.test_integration_agent_dependencies()
        self.test_results['integration']['service_connectivity'] = self.test_integration_service_connectivity()
        
        # Regression Testing
        self.logger.info("Running Regression Tests...")
        self.test_results['regression']['agent_compatibility'] = self.test_regression_agent_compatibility()
        
        # Smoke Testing
        self.logger.info("Running Smoke Tests...")
        self.test_results['smoke']['critical_agents'] = self.test_smoke_critical_agents()
        
        # Performance Testing
        self.logger.info("Running Performance Tests...")
        self.test_results['performance']['agent_loading'] = self.test_performance_agent_loading()
        self.test_results['performance']['memory_usage'] = self.test_performance_memory_usage()
        
        # Load Testing
        self.logger.info("Running Load Tests...")
        self.test_results['load']['concurrent_access'] = self.test_load_concurrent_agent_access()
        
        # Stress Testing
        self.logger.info("Running Stress Tests...")
        self.test_results['stress']['maximum_load'] = self.test_stress_maximum_load()
        
        return self.test_results
        
    def generate_test_report(self) -> str:
        """Generate comprehensive test report"""
        if not any(self.test_results.values()):
            self.run_all_tests()
            
        report = []
        report.append("# COMPREHENSIVE TESTING REPORT")
        report.append("=" * 50)
        report.append(f"Generated: {datetime.now().isoformat()}")
        report.append(f"Total Agents Tested: {len(self.agents)}")
        report.append("")
        
        # Summary statistics
        total_tests = 0
        passed_tests = 0
        
        for test_type, test_data in self.test_results.items():
            report.append(f"## {test_type.upper()} TESTING RESULTS")
            report.append("-" * 30)
            
            for test_name, results in test_data.items():
                if isinstance(results, dict):
                    if test_name == 'maximum_load':
                        # Special handling for stress test results
                        report.append(f"**{test_name}:**")
                        report.append(f"  Operations: {results.get('operations_completed', 0)}")
                        report.append(f"  Errors: {results.get('errors', 0)}")
                        report.append(f"  Avg Response Time: {results.get('avg_response_time', 0):.4f}s")
                        report.append(f"  Max Memory: {results.get('max_memory_usage', 0):.2f}MB")
                    else:
                        passed = sum(1 for v in results.values() if v is True or (isinstance(v, (int, float)) and v < float('inf')))
                        total = len(results)
                        total_tests += total
                        passed_tests += passed
                        
                        report.append(f"**{test_name}:** {passed}/{total} passed")
                        
                        # Show failed tests
                        failed = [k for k, v in results.items() if v is False or (isinstance(v, (int, float)) and v == float('inf'))]
                        if failed:
                            report.append(f"  Failed: {', '.join(failed[:5])}{'...' if len(failed) > 5 else ''}")
                            
            report.append("")
            
        # Overall summary
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        report.append(f"## OVERALL SUMMARY")
        report.append(f"Total Tests: {total_tests}")
        report.append(f"Passed: {passed_tests}")
        report.append(f"Failed: {total_tests - passed_tests}")
        report.append(f"Success Rate: {success_rate:.1f}%")
        
        return "\n".join(report)
        
    def save_test_results(self, filename: str = "test_results.json"):
        """Save test results to file"""
        output_path = self.agents_dir / filename
        with open(output_path, 'w') as f:
            json.dump(self.test_results, f, indent=2, default=str)
        self.logger.info(f"Test results saved to {output_path}")
        
if __name__ == "__main__":
    framework = ComprehensiveTestingFramework()
    results = framework.run_all_tests()
    
    # Generate and save report
    report = framework.generate_test_report()
    
    # Save results
    framework.save_test_results()
    
    # Save report
    report_path = Path("./agents/COMPREHENSIVE_TEST_REPORT.md")
    with open(report_path, 'w') as f:
        f.write(report)
        
    print("\n" + "=" * 60)
    print("COMPREHENSIVE TESTING COMPLETED")
    print("=" * 60)
    print(f"Report saved to: {report_path}")
    print(f"Results saved to: ./agents/test_results.json")
    print("\nSummary:")
    print(report.split("## OVERALL SUMMARY")[-1])
