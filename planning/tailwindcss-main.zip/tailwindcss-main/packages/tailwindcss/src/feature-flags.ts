export const enableContainerSizeUtility = process.env.FEATURES_ENV !== 'stable'
