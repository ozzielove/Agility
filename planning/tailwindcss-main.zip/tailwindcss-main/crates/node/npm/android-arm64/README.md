# `@tailwindcss/oxide-android-arm64`

This is the **aarch64-linux-android** binary for `@tailwindcss/oxide`
